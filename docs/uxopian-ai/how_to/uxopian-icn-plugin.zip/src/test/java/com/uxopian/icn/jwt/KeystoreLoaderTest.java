package com.uxopian.icn.jwt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class KeystoreLoaderTest
{

    private static final String ALIAS = "test-alias";

    private static final String PASSWORD = "test-pass";

    private static Path generateP12Keystore(Path dir) throws Exception
    {
        Path p12 = dir.resolve("test.p12");
        ProcessBuilder processBuilder = new ProcessBuilder(System.getProperty("java.home") + "/bin/keytool",
                "-genkeypair", "-alias", ALIAS, "-keyalg", "RSA", "-keysize", "2048", "-storetype", "PKCS12",
                "-keystore", p12.toString(), "-storepass", PASSWORD, "-keypass", PASSWORD, "-dname",
                "CN=uxopian-icn-plugin-test", "-validity", "1");
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();
        int exitCode = process.waitFor();
        assertEquals(0, exitCode, "keytool must generate the test keystore successfully");
        return p12;
    }

    @Test
    @DisplayName("loads private and public key from a valid PKCS12 keystore")
    void loadsPrivateAndPublicKeyFromValidKeystore(@TempDir Path tempDir) throws Exception
    {
        Path p12 = generateP12Keystore(tempDir);

        KeystoreLoader loader = new KeystoreLoader(p12.toString(), ALIAS, PASSWORD);

        assertNotNull(loader.getPrivateKey());
        assertNotNull(loader.getPublicKey());

        String pem = loader.getPublicKeyPem();
        assertTrue(pem.startsWith("-----BEGIN PUBLIC KEY-----"));
        assertTrue(pem.trim().endsWith("-----END PUBLIC KEY-----"));
    }

    @Test
    @DisplayName("throws when the alias does not exist in the keystore")
    void throwsWhenAliasDoesNotExist(@TempDir Path tempDir) throws Exception
    {
        Path p12 = generateP12Keystore(tempDir);

        assertThrows(Exception.class, () -> new KeystoreLoader(p12.toString(), "unknown-alias", PASSWORD));
    }
}
