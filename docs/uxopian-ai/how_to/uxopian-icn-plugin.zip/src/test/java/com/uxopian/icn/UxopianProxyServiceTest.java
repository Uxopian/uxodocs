package com.uxopian.icn;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class UxopianProxyServiceTest
{

    private final UxopianProxyService service = new UxopianProxyService();

    @Test
    @DisplayName("execute with op=public-key does not throw, whether or not the keystore is available")
    void executeWithPublicKeyOpDoesNotThrow() throws Exception
    {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        when(request.getParameter("op")).thenReturn("public-key");
        when(response.getWriter()).thenReturn(new PrintWriter(new StringWriter()));

        assertDoesNotThrow(() -> service.execute(null, request, response));
    }
}
