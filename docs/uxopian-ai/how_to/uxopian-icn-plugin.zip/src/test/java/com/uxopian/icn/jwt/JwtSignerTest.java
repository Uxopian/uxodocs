package com.uxopian.icn.jwt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;
import java.util.Base64;
import java.util.Collections;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class JwtSignerTest
{

    private static KeyPair generateKeyPair() throws Exception
    {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        return keyPairGenerator.generateKeyPair();
    }

    @Test
    @DisplayName("sign produces a valid three-part RS256 JWT")
    void signProducesValidRs256Jwt() throws Exception
    {
        KeyPair keyPair = generateKeyPair();

        String jwt = JwtSigner.sign("alice", Collections.singletonList("ADMIN"), keyPair.getPrivate());

        String[] parts = jwt.split("\\.");
        assertEquals(3, parts.length);

        String header = new String(Base64.getUrlDecoder().decode(parts[0]));
        String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
        assertTrue(header.contains("\"alg\":\"RS256\""));
        assertTrue(payload.contains("\"sub\":\"alice\""));
        assertTrue(payload.contains("\"roles\":[\"ADMIN\"]"));

        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initVerify(keyPair.getPublic());
        signature.update((parts[0] + "." + parts[1]).getBytes("UTF-8"));
        assertTrue(signature.verify(Base64.getUrlDecoder().decode(parts[2])));
    }

    @Test
    @DisplayName("sign escapes special characters in the subject")
    void signEscapesSpecialCharactersInSubject() throws Exception
    {
        KeyPair keyPair = generateKeyPair();

        String jwt = JwtSigner.sign("a\"b\\c", Collections.<String> emptyList(), keyPair.getPrivate());

        String payload = new String(Base64.getUrlDecoder().decode(jwt.split("\\.")[1]));
        assertTrue(payload.contains("\"sub\":\"a\\\"b\\\\c\""));
        assertTrue(payload.contains("\"roles\":[]"));
    }
}
