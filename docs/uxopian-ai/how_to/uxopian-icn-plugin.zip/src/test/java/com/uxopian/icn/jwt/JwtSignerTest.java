package com.uxopian.icn.jwt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;
import java.util.Base64;
import java.util.Collections;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class JwtSignerTest
{

    private static KeyPair keyPair;

    @BeforeAll
    static void generateKeyPair() throws Exception
    {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        keyPair = keyPairGenerator.generateKeyPair();
    }

    @Test
    @DisplayName("sign produces a valid three-part RS256 JWT")
    void signProducesValidRs256Jwt() throws Exception
    {
        String jwt = JwtSigner.sign("alice", Collections.singletonList("ADMIN"), "OS_ARENDER_DEV",
                keyPair.getPrivate());

        String[] parts = jwt.split("\\.");
        assertEquals(3, parts.length);

        assertTrue(decode(parts[0]).contains("\"alg\":\"RS256\""));
        assertTrue(decode(parts[1]).contains("\"sub\":\"alice\""));
        assertTrue(decode(parts[1]).contains("\"roles\":[\"ADMIN\"]"));
        assertTrue(decode(parts[1]).contains("\"tenantId\":\"OS_ARENDER_DEV\""));

        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initVerify(keyPair.getPublic());
        signature.update((parts[0] + "." + parts[1]).getBytes(StandardCharsets.UTF_8));
        assertTrue(signature.verify(Base64.getUrlDecoder().decode(parts[2])));
    }

    @Test
    @DisplayName("sign escapes special characters in the subject")
    void signEscapesSpecialCharactersInSubject() throws Exception
    {
        String jwt = JwtSigner.sign("a\"b\\c", Collections.<String> emptyList(), "OS_ARENDER_DEV",
                keyPair.getPrivate());

        String payload = decode(jwt.split("\\.")[1]);
        assertTrue(payload.contains("\"sub\":\"a\\\"b\\\\c\""));
        assertTrue(payload.contains("\"roles\":[]"));
    }

    @Test
    @DisplayName("sign omits the tenantId claim when the repository id is null or empty")
    void signOmitsTenantIdWhenRepositoryIdMissing() throws Exception
    {
        String jwtWithNull = JwtSigner.sign("alice", Collections.<String> emptyList(), null, keyPair.getPrivate());
        String jwtWithEmpty = JwtSigner.sign("alice", Collections.<String> emptyList(), "", keyPair.getPrivate());

        assertTrue(!decode(jwtWithNull.split("\\.")[1]).contains("tenantId"));
        assertTrue(!decode(jwtWithEmpty.split("\\.")[1]).contains("tenantId"));
    }

    private static String decode(String base64Url)
    {
        return new String(Base64.getUrlDecoder().decode(base64Url), StandardCharsets.UTF_8);
    }
}
