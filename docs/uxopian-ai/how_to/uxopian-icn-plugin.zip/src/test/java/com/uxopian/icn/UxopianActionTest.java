package com.uxopian.icn;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Locale;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class UxopianActionTest
{
    private final UxopianAction action = new UxopianAction();

    @Test
    @DisplayName("the action keeps its id, so the menus ICN admins already set up still find it")
    void keepsItsId()
    {
        assertEquals("UxopianAction", action.getId());
    }

    @Test
    @DisplayName("the action is named after the AI actions it opens")
    void isNamedUxopianAi()
    {
        assertEquals("Uxopian AI", action.getName(Locale.ENGLISH));
    }

    @Test
    @DisplayName("the action accepts a selection of several documents")
    void acceptsSeveralDocuments()
    {
        assertTrue(action.isMultiDoc());
    }
}
