package com.uxopian.icn;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.Locale;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class UxopianActionTest
{

    private final UxopianAction action = new UxopianAction();

    @Test
    @DisplayName("getId returns the action identifier")
    void getIdReturnsActionIdentifier()
    {
        assertEquals("UxopianAction", action.getId());
    }

    @Test
    @DisplayName("getName returns the display name")
    void getNameReturnsDisplayName()
    {
        assertEquals("Open in Uxopian", action.getName(Locale.ENGLISH));
    }

    @Test
    @DisplayName("getActionFunction returns the dojo module path")
    void getActionFunctionReturnsDojoModulePath()
    {
        assertEquals("uxopianPluginDojo/actionHandler", action.getActionFunction());
    }

    @Test
    @DisplayName("getServerTypes returns p8")
    void getServerTypesReturnsP8()
    {
        assertEquals("p8", action.getServerTypes());
    }

    @Test
    @DisplayName("isMultiDoc returns false")
    void isMultiDocReturnsFalse()
    {
        assertFalse(action.isMultiDoc());
    }
}
