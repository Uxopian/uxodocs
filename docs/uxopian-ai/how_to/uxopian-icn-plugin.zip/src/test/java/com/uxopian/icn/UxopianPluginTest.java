package com.uxopian.icn;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class UxopianPluginTest
{

    private final UxopianPlugin plugin = new UxopianPlugin();

    @Test
    @DisplayName("getActions returns a single UxopianAction")
    void getActionsReturnsSingleUxopianAction()
    {
        assertEquals(1, plugin.getActions().length);
        assertInstanceOf(UxopianAction.class, plugin.getActions()[0]);
    }

    @Test
    @DisplayName("getServices returns a single UxopianProxyService")
    void getServicesReturnsSingleUxopianProxyService()
    {
        assertEquals(1, plugin.getServices().length);
        assertInstanceOf(UxopianProxyService.class, plugin.getServices()[0]);
    }
}
