package com.uxopian.icn;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

import java.util.Locale;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class UxopianPluginTest
{

    private final UxopianPlugin plugin = new UxopianPlugin();

    @Test
    @DisplayName("getId returns the plugin identifier")
    void getIdReturnsPluginIdentifier()
    {
        assertEquals("UxopianPlugin", plugin.getId());
    }

    @Test
    @DisplayName("getName returns the display name")
    void getNameReturnsDisplayName()
    {
        assertEquals("Uxopian Plugin", plugin.getName(Locale.ENGLISH));
    }

    @Test
    @DisplayName("getScript returns the client script path")
    void getScriptReturnsClientScriptPath()
    {
        assertEquals("actionHandler.js", plugin.getScript());
    }

    @Test
    @DisplayName("getDojoModule returns the dojo module name")
    void getDojoModuleReturnsDojoModuleName()
    {
        assertEquals("uxopianPluginDojo", plugin.getDojoModule());
    }

    @Test
    @DisplayName("getConfigurationDijitClass returns the configuration pane widget")
    void getConfigurationDijitClassReturnsConfigurationPaneWidget()
    {
        assertEquals("uxopianPluginDojo.ConfigurationPane", plugin.getConfigurationDijitClass());
    }

    @Test
    @DisplayName("getActions returns a single UxopianAction")
    void getActionsReturnsSingleUxopianAction()
    {
        assertEquals(1, plugin.getActions().length);
        assertInstanceOf(UxopianAction.class, plugin.getActions()[0]);
    }

    @Test
    @DisplayName("getServices returns a single UxopianProxyService")
    void getServicesReturnsSingleUxopianProxyService()
    {
        assertEquals(1, plugin.getServices().length);
        assertInstanceOf(UxopianProxyService.class, plugin.getServices()[0]);
    }
}
