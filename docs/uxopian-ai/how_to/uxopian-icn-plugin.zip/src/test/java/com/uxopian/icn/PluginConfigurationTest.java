package com.uxopian.icn;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class PluginConfigurationTest
{
    @Test
    @DisplayName("parse reads the host and the scripts the AI actions come from")
    void parseReadsTheHostAndTheScripts() throws Exception
    {
        PluginConfiguration configuration = PluginConfiguration
                .parse("{\"uxopianAiHost\":\"https://ai.example.com\",\"scripts\":\"icn-actions, icn-extra\"}");

        assertEquals("https://ai.example.com", configuration.getUxopianAiHost());
        assertEquals("icn-actions, icn-extra", configuration.getScripts());
    }

    @Test
    @DisplayName("parse leaves the scripts out of a configuration saved before they existed")
    void parseLeavesTheScriptsOutOfAnOlderConfiguration() throws Exception
    {
        PluginConfiguration configuration = PluginConfiguration.parse("{\"uxopianAiHost\":\"https://ai.example.com\"}");

        assertEquals("https://ai.example.com", configuration.getUxopianAiHost());
        assertNull(configuration.getScripts());
    }

    @Test
    @DisplayName("parse of a plugin never configured gives neither host nor scripts")
    void parseOfAnEmptyConfigurationGivesNothing() throws Exception
    {
        PluginConfiguration configuration = PluginConfiguration.parse(null);

        assertNull(configuration.getUxopianAiHost());
        assertNull(configuration.getScripts());
    }
}
