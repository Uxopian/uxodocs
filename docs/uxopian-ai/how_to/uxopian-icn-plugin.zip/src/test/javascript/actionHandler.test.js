const ACTION_HANDLER_PATH = '../../main/resources/com/uxopian/icn/WebContent/actionHandler.js';

function flushPromises() {
    return new Promise((resolve) => setTimeout(resolve, 0));
}

function loadActionHandler() {
    jest.resetModules();
    global.define = jest.fn();
    require(ACTION_HANDLER_PATH);
}

describe('actionHandler', () => {
    beforeEach(() => {
        document.body.innerHTML = '<div data-dojo-attach-point="applicationMenu"></div>';
    });

    afterEach(() => {
        delete window._uxopianAI;
        delete window.ecm;
        delete window.open;
        delete global.define;
    });

    it('injects the AI chat and admin buttons into the application menu', () => {
        loadActionHandler();

        expect(document.getElementById('uxopian-ai-navbar-btn')).not.toBeNull();
        expect(document.getElementById('uxopian-ai-admin-btn')).not.toBeNull();
    });

    it('does not inject buttons when the application menu is hidden', async () => {
        const appMenu = document.querySelector('[data-dojo-attach-point="applicationMenu"]');
        appMenu.style.visibility = 'hidden';

        loadActionHandler();

        expect(document.getElementById('uxopian-ai-navbar-btn')).toBeNull();
        expect(document.getElementById('uxopian-ai-admin-btn')).toBeNull();

        appMenu.style.visibility = 'visible';
        await flushPromises();
    });

    it('opens the admin console using the host fetched from the plugin service (op=config)', async () => {
        window.ecm = {
            model: {
                Request: {
                    invokePluginService: jest.fn((pluginId, serviceId, options) => {
                        if (options.requestParams.op === 'config') {
                            options.requestCompleteCallback({ uxopianAiHost: 'https://configured.example.com/gateway' });
                        } else if (options.requestParams.op === 'admin-token') {
                            options.requestCompleteCallback({ token: 'test-admin-token' });
                        }
                    })
                }
            }
        };
        window.open = jest.fn();

        loadActionHandler();
        window._uxopianAI.openAdmin();
        await flushPromises();

        expect(window.open).toHaveBeenCalledTimes(1);
        const openedUrl = window.open.mock.calls[0][0];
        expect(openedUrl.startsWith('https://configured.example.com/auth/login')).toBe(true);
        expect(openedUrl).toContain('token=test-admin-token');
        expect(openedUrl).toContain('redirect=' + encodeURIComponent('/gateway/admin/'));
    });

    it('does not open the admin console when the plugin service returns no configuration', async () => {
        window.ecm = {
            model: {
                Request: {
                    invokePluginService: jest.fn((pluginId, serviceId, options) => {
                        if (options.requestParams.op === 'config') {
                            options.requestCompleteCallback({});
                        } else if (options.requestParams.op === 'admin-token') {
                            options.requestCompleteCallback({ token: 'test-admin-token' });
                        }
                    })
                }
            }
        };
        window.open = jest.fn();
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

        loadActionHandler();
        window._uxopianAI.openAdmin();
        await flushPromises();

        expect(window.open).not.toHaveBeenCalled();
        expect(consoleErrorSpy).toHaveBeenCalledWith(
            '[Uxopian AI] Failed to open admin:',
            expect.objectContaining({ message: expect.stringContaining('not configured') })
        );

        consoleErrorSpy.mockRestore();
    });
});
