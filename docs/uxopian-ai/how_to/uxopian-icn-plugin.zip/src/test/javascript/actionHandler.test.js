/**
 * @jest-environment-options {"runScripts": "dangerously"}
 */
const ACTION_HANDLER_PATH = '../../main/resources/com/uxopian/icn/WebContent/actionHandler.js';

const CONFIGURED_HOST = 'https://configured.example.com/gui/gateway/uxopian-ai/filenet';

function flushPromises() {
    return new Promise((resolve) => setTimeout(resolve, 0));
}

function loadActionHandler() {
    jest.resetModules();
    global.define = jest.fn();
    require(ACTION_HANDLER_PATH);
}

function mockProxyService(responseByOp) {
    window.ecm = {
        model: {
            Request: {
                invokePluginService: jest.fn((pluginId, serviceId, options) => {
                    const response = responseByOp[options.requestParams.op];
                    if (response) {
                        options.requestCompleteCallback(response);
                    }
                })
            }
        }
    };
}

describe('actionHandler', () => {
    let nativeFetch;
    let NativeXhr;

    beforeEach(() => {
        document.body.innerHTML = '<div data-dojo-attach-point="applicationMenu"></div>';
        nativeFetch = window.fetch;
        NativeXhr = window.XMLHttpRequest;
    });

    afterEach(() => {
        window.fetch = nativeFetch;
        window.XMLHttpRequest = NativeXhr;
        delete window._uxopianAI;
        delete window.ecm;
        delete window.open;
        delete window.createChat;
        delete global.define;
    });

    it('injects the AI chat and admin buttons into the application menu', () => {
        loadActionHandler();

        expect(document.getElementById('uxopian-ai-navbar-btn')).not.toBeNull();
        expect(document.getElementById('uxopian-ai-admin-btn')).not.toBeNull();
    });

    it('does not inject buttons when the application menu is hidden', async () => {
        const appMenu = document.querySelector('[data-dojo-attach-point="applicationMenu"]');
        appMenu.style.visibility = 'hidden';

        loadActionHandler();

        expect(document.getElementById('uxopian-ai-navbar-btn')).toBeNull();
        expect(document.getElementById('uxopian-ai-admin-btn')).toBeNull();

        appMenu.style.visibility = 'visible';
        await flushPromises();
    });

    it('opens the chat with the configured host and a user token', async () => {
        mockProxyService({ config: { uxopianAiHost: CONFIGURED_HOST }, token: { token: 'test-user-token' } });
        window.createChat = jest.fn();

        loadActionHandler();
        window._uxopianAI.openChat(window._uxopianAI.buildChatRequest());
        await flushPromises();

        expect(window.createChat).toHaveBeenCalledTimes(1);
        const chatOptions = window.createChat.mock.calls[0][0];
        expect(chatOptions.endpoint).toBe(CONFIGURED_HOST);
        expect(chatOptions.wsEndpoint).toBe('wss://configured.example.com/gui/gateway/uxopian-ai/filenet');
        expect(chatOptions.request.inputs).toEqual([]);
    });

    it('attaches a freshly fetched bearer token to every intercepted request, not a stale one', async () => {
        mockProxyService({ config: { uxopianAiHost: CONFIGURED_HOST }, token: { token: 'first-token' } });
        window.createChat = jest.fn();
        const fetchMock = jest.fn().mockResolvedValue({});
        window.fetch = fetchMock;

        loadActionHandler();
        window._uxopianAI.openChat(window._uxopianAI.buildChatRequest());
        await flushPromises();

        window.ecm.model.Request.invokePluginService.mockImplementation((pluginId, serviceId, options) => {
            options.requestCompleteCallback({ token: 'second-token' });
        });
        await window.fetch(CONFIGURED_HOST + '/api/something');

        expect(fetchMock).toHaveBeenCalledTimes(1);
        const [, init] = fetchMock.mock.calls[0];
        expect(init.headers.Authorization).toBe('Bearer second-token');
    });

    it('opens the admin console using the host fetched from the plugin service (op=config)', async () => {
        mockProxyService({ config: { uxopianAiHost: CONFIGURED_HOST }, 'admin-token': { token: 'test-admin-token' } });
        window.open = jest.fn();

        loadActionHandler();
        window._uxopianAI.openAdmin();
        await flushPromises();

        expect(window.open).toHaveBeenCalledTimes(1);
        const openedUrl = window.open.mock.calls[0][0];
        expect(openedUrl.startsWith('https://configured.example.com/gui/gateway/auth/login')).toBe(true);
        expect(openedUrl).toContain('token=test-admin-token');
        expect(openedUrl).toContain('redirect=' + encodeURIComponent('/gui/gateway/uxopian-ai/filenet/admin/'));
    });

    it('does not open the admin console when the plugin service returns no configuration', async () => {
        mockProxyService({ config: {}, 'admin-token': { token: 'test-admin-token' } });
        window.open = jest.fn();
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

        loadActionHandler();
        window._uxopianAI.openAdmin();
        await flushPromises();

        expect(window.open).not.toHaveBeenCalled();
        expect(consoleErrorSpy).toHaveBeenCalledWith(
            '[Uxopian AI] Failed to open admin:',
            expect.objectContaining({ message: expect.stringContaining('not configured') })
        );

        consoleErrorSpy.mockRestore();
    });
});

describe('quick actions', () => {
    let nativeFetch;
    let fetchMock;
    let proxyResponses;

    function docItem(id, className, name) {
        return {
            id: className + ',{OS-1},' + id,
            template: className,
            name: name,
            mimetype: 'application/pdf',
            isFolder: () => false
        };
    }

    function folder(id, name) {
        return { id: 'Folder,{OS-1},' + id, template: 'Folder', name: name, mimetype: 'folder', isFolder: () => true };
    }

    function scriptResponse(content) {
        return { ok: true, status: 200, text: () => Promise.resolve(content) };
    }

    async function showActions(items) {
        await window._uxopianAI.showActions(items);
    }

    function menuLabels() {
        return Array.from(document.querySelectorAll('#uxopian-ai-actions-menu button')).map((b) => b.textContent);
    }

    function clickMenuItem(label) {
        Array.from(document.querySelectorAll('#uxopian-ai-actions-menu button'))
            .find((b) => b.textContent === label).click();
    }

    beforeEach(() => {
        document.head.innerHTML = '';
        document.body.innerHTML = '<div data-dojo-attach-point="applicationMenu"></div>';
        nativeFetch = window.fetch;
        fetchMock = jest.fn().mockImplementation((url) => Promise.resolve(scriptResponse('/* ' + url.split('/').pop() + ' */')));
        window.fetch = fetchMock;
        window.createChat = jest.fn();
        proxyResponses = {
            config: { uxopianAiHost: CONFIGURED_HOST, scripts: 'icn-actions, icn-extra' },
            token: { token: 'test-user-token' }
        };
        mockProxyService(proxyResponses);
        loadActionHandler();
    });

    afterEach(() => {
        window.fetch = nativeFetch;
        delete window._uxopianAI;
        delete window.UxopianAI;
        delete window.ecm;
        delete window.createChat;
        delete global.define;
    });

    function scriptRegistering(labels) {
        return labels.map((label) => 'UxopianAI.registerAction({ id: "' + label + '", label: "' + label
            + '", onExecute: function () {} });').join('\n');
    }

    function serveScripts(contentById) {
        fetchMock.mockImplementation((url) => Promise.resolve(scriptResponse(contentById[url.split('/').pop()] || '')));
    }

    it('runs every configured script inline with the user token, revalidating it at each opening', async () => {
        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);
        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);

        const scriptCalls = fetchMock.mock.calls.filter(([url]) => url.indexOf('/api/v1/scripts/') !== -1);
        expect(scriptCalls.map(([url]) => url)).toEqual([
            CONFIGURED_HOST + '/api/v1/scripts/icn-actions',
            CONFIGURED_HOST + '/api/v1/scripts/icn-extra',
            CONFIGURED_HOST + '/api/v1/scripts/icn-actions',
            CONFIGURED_HOST + '/api/v1/scripts/icn-extra'
        ]);
        expect(scriptCalls.every(([, init]) => init.cache === 'no-cache')).toBe(true);
        expect(scriptCalls[0][1].headers.Authorization).toBe('Bearer test-user-token');
        const scripts = document.head.querySelectorAll('script[data-uxopian-action-script]');
        expect(Array.from(scripts).map((script) => script.textContent)).toEqual(['/* icn-actions */', '/* icn-extra */']);
        expect(Array.from(scripts).every((script) => !script.src)).toBe(true);
    });

    it('runs a script again once it changed in Uxopian AI, dropping the actions it no longer registers', async () => {
        serveScripts({ 'icn-actions': scriptRegistering(['Summarize', 'Translate']) });
        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);
        expect(menuLabels()).toEqual(['Summarize', 'Translate']);

        serveScripts({ 'icn-actions': scriptRegistering(['Translate', 'Compare']) });
        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);

        expect(menuLabels()).toEqual(['Translate', 'Compare']);
        expect(document.head.querySelectorAll('script[data-uxopian-action-script="icn-actions"]')).toHaveLength(1);
    });

    it('follows the scripts listed in the plugin configuration without reloading ICN', async () => {
        serveScripts({ 'icn-actions': scriptRegistering(['Summarize']), 'icn-extra': scriptRegistering(['Compare']) });
        proxyResponses.config.scripts = 'icn-actions';
        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);
        expect(menuLabels()).toEqual(['Summarize']);

        proxyResponses.config.scripts = 'icn-extra';
        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);

        expect(menuLabels()).toEqual(['Compare']);
    });

    it('still offers the actions of the other scripts when one cannot be loaded', async () => {
        fetchMock.mockImplementation((url) => Promise.resolve(url.endsWith('/icn-extra')
            ? { ok: false, status: 401, text: () => Promise.resolve('') } : scriptResponse('/* script */')));
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
        window.UxopianAI.registerAction({ id: 'summarize', label: 'Summarize', onExecute: jest.fn() });

        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);

        expect(menuLabels()).toEqual(['Summarize']);
        expect(consoleErrorSpy).toHaveBeenCalledWith('[Uxopian AI] Failed to load script icn-extra:',
            expect.objectContaining({ message: expect.stringContaining('401') }));
        consoleErrorSpy.mockRestore();
    });

    it('runs the chosen action with the FileNet id, class, name and type of the selected document', async () => {
        const onExecute = jest.fn();
        window.UxopianAI.registerAction({ id: 'summarize', label: 'Summarize', onExecute: onExecute });

        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);
        clickMenuItem('Summarize');

        expect(onExecute).toHaveBeenCalledTimes(1);
        expect(onExecute.mock.calls[0][0].items).toEqual([
            { objectId: '{DOC-1}', className: 'Invoice', name: 'invoice.pdf', mimeType: 'application/pdf' }
        ]);
        expect(onExecute.mock.calls[0][0].folder).toBeNull();
        expect(document.getElementById('uxopian-ai-actions-menu')).toBeNull();
    });

    it('offers only the multi-document actions for a selection of several documents', async () => {
        window.UxopianAI.registerAction({ id: 'summarize', label: 'Summarize', onExecute: jest.fn() });
        window.UxopianAI.registerAction({ id: 'compare', label: 'Compare', multiDoc: true, onExecute: jest.fn() });

        await showActions([docItem('{DOC-1}', 'Invoice', 'a.pdf'), docItem('{DOC-2}', 'Invoice', 'b.pdf')]);

        expect(menuLabels()).toEqual(['Compare']);
    });

    it('offers only the folder actions for a folder, and hands the folder to the action', async () => {
        const onExecute = jest.fn();
        window.UxopianAI.registerAction({ id: 'summarize', label: 'Summarize', onExecute: jest.fn() });
        window.UxopianAI.registerAction({
            id: 'check-folder', label: 'Check the folder', folder: true, documents: false, onExecute: onExecute
        });

        await showActions([folder('{FOLDER-1}', 'Claims 2026')]);
        expect(menuLabels()).toEqual(['Check the folder']);

        clickMenuItem('Check the folder');
        expect(onExecute.mock.calls[0][0].folder).toEqual({ objectId: '{FOLDER-1}', className: 'Folder', name: 'Claims 2026' });
        expect(onExecute.mock.calls[0][0].items).toEqual([]);
    });

    it('does not offer a folder-only action for a document', async () => {
        window.UxopianAI.registerAction({
            id: 'check-folder', label: 'Check the folder', folder: true, documents: false, onExecute: jest.fn()
        });

        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);

        expect(menuLabels()).toEqual([]);
        expect(document.getElementById('uxopian-ai-actions-menu').textContent)
            .toContain('No AI action for this selection');
    });

    it('lets an action open the chat with its request', async () => {
        window.UxopianAI.registerAction({
            id: 'summarize',
            label: 'Summarize',
            onExecute: (ctx) => ctx.openChat({ inputs: [{ role: 'user', content: [{ type: 'PROMPT',
                value: 'summarizeDocumentText', payload: { documentId: ctx.items[0].objectId } }] }] })
        });

        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);
        clickMenuItem('Summarize');
        await flushPromises();
        await flushPromises();

        expect(window.createChat).toHaveBeenCalledTimes(1);
        expect(window.createChat.mock.calls[0][0].request.inputs[0].content[0].payload)
            .toEqual({ documentId: '{DOC-1}' });
    });

    it('opens the actions where the user clicked, not at a fixed place', async () => {
        window.UxopianAI.registerAction({ id: 'summarize', label: 'Summarize', onExecute: jest.fn() });
        document.body.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, clientX: 320, clientY: 410 }));

        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);

        const menu = document.getElementById('uxopian-ai-actions-menu');
        expect(menu.style.left).toBe('320px');
        expect(menu.style.top).toBe('410px');
    });

    it('replaces an action registered again under the same id', async () => {
        window.UxopianAI.registerAction({ id: 'summarize', label: 'Summarize', onExecute: jest.fn() });
        window.UxopianAI.registerAction({ id: 'summarize', label: 'Summary', onExecute: jest.fn() });

        await showActions([docItem('{DOC-1}', 'Invoice', 'invoice.pdf')]);

        expect(menuLabels()).toEqual(['Summary']);
    });
});

describe('Uxopian AI in the ICN menus', () => {
    let desktop;
    let originalLoadMenuActions;
    let actionsHandler;
    let nativeFetch;
    let scriptContent;

    const SCRIPT = [
        'UxopianAI.registerAction({ id: "summarize", label: "Summarize", onExecute: function (ctx) { window.__executed = ctx; } });',
        'UxopianAI.registerAction({ id: "compare", label: "Compare", multiDoc: true, onExecute: function () {} });',
        'UxopianAI.registerAction({ id: "check-folder", label: "Check the folder", folder: true, documents: false,',
        '    onExecute: function (ctx) { window.__executed = ctx; } });'
    ].join('\n');

    function loadMenu(menuType) {
        window.ecm.model.desktop.loadMenuActions(menuType, jest.fn());
        return desktop.actionLists[menuType];
    }

    async function openMenuTwice(menuType) {
        loadMenu(menuType);
        for (let i = 0; i < 5; i++) {
            await flushPromises();
        }
        return loadMenu(menuType);
    }

    function submenu(actions) {
        return actions.find((action) => action.id === 'UxopianAI');
    }

    beforeEach(() => {
        document.head.innerHTML = '';
        document.body.innerHTML = '<div data-dojo-attach-point="applicationMenu"></div>';
        mockProxyService({
            config: { uxopianAiHost: CONFIGURED_HOST, scripts: 'icn-actions' },
            token: { token: 'test-user-token' }
        });
        scriptContent = SCRIPT;
        nativeFetch = window.fetch;
        window.fetch = jest.fn(() => Promise.resolve({ ok: true, status: 200, text: () => Promise.resolve(scriptContent) }));
        originalLoadMenuActions = jest.fn();
        actionsHandler = {};
        desktop = {
            actionLists: {
                ItemContextMenu: [{ id: 'View' }],
                FolderContextMenu: [{ id: 'OpenFolder' }],
                BannerToolsContextMenu: [{ id: 'Import' }]
            },
            loadMenuActions: originalLoadMenuActions,
            getActionsHandler: () => actionsHandler
        };
        window.ecm.model.desktop = desktop;
        window.ecm.model.Action = function (properties) { Object.assign(this, properties); };
        window.createChat = jest.fn();
        loadActionHandler();
    });

    afterEach(() => {
        window.fetch = nativeFetch;
        delete window._uxopianAI;
        delete window.UxopianAI;
        delete window.ecm;
        delete window.createChat;
        delete window.__executed;
        delete global.define;
    });

    it('puts the document actions of the scripts in a Uxopian AI submenu of the document menus', async () => {
        const actions = await openMenuTwice('ItemContextMenu');

        expect(actions.map((action) => action.id)).toEqual(['View', 'UxopianAI']);
        expect(submenu(actions).name).toBe('Uxopian AI');
        expect(submenu(actions).subActions.map((action) => [action.name, action.multiDoc]))
            .toEqual([['Summarize', false], ['Compare', true]]);
        expect(originalLoadMenuActions).toHaveBeenCalledWith('ItemContextMenu', expect.any(Function));
    });

    it('puts the folder actions in the folder menus', async () => {
        const actions = await openMenuTwice('FolderContextMenu');

        expect(submenu(actions).subActions.map((action) => action.name)).toEqual(['Check the folder']);
    });

    it('runs the chosen action with the items the menu was opened on', async () => {
        const summarize = submenu(await openMenuTwice('ItemContextMenu')).subActions[0];

        actionsHandler[summarize.action]({}, [
            { id: 'Invoice,{OS-1},{DOC-1}', template: 'Invoice', name: 'a.pdf', mimetype: 'application/pdf',
                isFolder: () => false }
        ]);

        expect(window.__executed.items).toEqual([
            { objectId: '{DOC-1}', className: 'Invoice', name: 'a.pdf', mimeType: 'application/pdf' }
        ]);
    });

    it('shows a script changed in Uxopian AI at a later opening, without reloading ICN', async () => {
        await openMenuTwice('ItemContextMenu');

        scriptContent = 'UxopianAI.registerAction({ id: "translate", label: "Translate", onExecute: function () {} });';
        const actions = await openMenuTwice('ItemContextMenu');

        expect(submenu(actions).subActions.map((action) => action.name)).toEqual(['Translate']);
        expect(actions.filter((action) => action.id === 'UxopianAI')).toHaveLength(1);
    });

    it('leaves the submenu out of a menu no action fits', async () => {
        scriptContent = 'UxopianAI.registerAction({ id: "summarize", label: "Summarize", onExecute: function () {} });';

        const actions = await openMenuTwice('FolderContextMenu');

        expect(actions.map((action) => action.id)).toEqual(['OpenFolder']);
    });

    it('leaves a menu alone when an administrator already placed the Uxopian AI action in it', async () => {
        desktop.actionLists.ItemContextMenu.push({ id: 'UxopianAction' });

        const actions = await openMenuTwice('ItemContextMenu');

        expect(actions.map((action) => action.id)).toEqual(['View', 'UxopianAction']);
    });

    it('does not touch the menus that are not about documents or folders', async () => {
        const actions = await openMenuTwice('BannerToolsContextMenu');

        expect(actions.map((action) => action.id)).toEqual(['Import']);
    });
});
