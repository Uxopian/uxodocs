const ACTION_HANDLER_PATH = '../../main/resources/com/uxopian/icn/WebContent/actionHandler.js';

const CONFIGURED_HOST = 'https://configured.example.com/gui/gateway/uxopian-ai/filenet';

function flushPromises() {
    return new Promise((resolve) => setTimeout(resolve, 0));
}

function loadActionHandler() {
    jest.resetModules();
    global.define = jest.fn();
    require(ACTION_HANDLER_PATH);
}

function mockProxyService(responseByOp) {
    window.ecm = {
        model: {
            Request: {
                invokePluginService: jest.fn((pluginId, serviceId, options) => {
                    const response = responseByOp[options.requestParams.op];
                    if (response) {
                        options.requestCompleteCallback(response);
                    }
                })
            }
        }
    };
}

describe('actionHandler', () => {
    let nativeFetch;
    let NativeXhr;

    beforeEach(() => {
        document.body.innerHTML = '<div data-dojo-attach-point="applicationMenu"></div>';
        nativeFetch = window.fetch;
        NativeXhr = window.XMLHttpRequest;
    });

    afterEach(() => {
        window.fetch = nativeFetch;
        window.XMLHttpRequest = NativeXhr;
        delete window._uxopianAI;
        delete window.ecm;
        delete window.open;
        delete window.createChat;
        delete global.define;
    });

    it('injects the AI chat and admin buttons into the application menu', () => {
        loadActionHandler();

        expect(document.getElementById('uxopian-ai-navbar-btn')).not.toBeNull();
        expect(document.getElementById('uxopian-ai-admin-btn')).not.toBeNull();
    });

    it('does not inject buttons when the application menu is hidden', async () => {
        const appMenu = document.querySelector('[data-dojo-attach-point="applicationMenu"]');
        appMenu.style.visibility = 'hidden';

        loadActionHandler();

        expect(document.getElementById('uxopian-ai-navbar-btn')).toBeNull();
        expect(document.getElementById('uxopian-ai-admin-btn')).toBeNull();

        appMenu.style.visibility = 'visible';
        await flushPromises();
    });

    it('opens the chat with the configured host and a user token', async () => {
        mockProxyService({ config: { uxopianAiHost: CONFIGURED_HOST }, token: { token: 'test-user-token' } });
        window.createChat = jest.fn();

        loadActionHandler();
        window._uxopianAI.openChat(window._uxopianAI.buildChatRequest());
        await flushPromises();

        expect(window.createChat).toHaveBeenCalledTimes(1);
        const chatOptions = window.createChat.mock.calls[0][0];
        expect(chatOptions.endpoint).toBe(CONFIGURED_HOST);
        expect(chatOptions.wsEndpoint).toBe('wss://configured.example.com/gui/gateway/uxopian-ai/filenet');
        expect(chatOptions.request.inputs).toEqual([]);
    });

    it('attaches a freshly fetched bearer token to every intercepted request, not a stale one', async () => {
        mockProxyService({ config: { uxopianAiHost: CONFIGURED_HOST }, token: { token: 'first-token' } });
        window.createChat = jest.fn();
        const fetchMock = jest.fn().mockResolvedValue({});
        window.fetch = fetchMock;

        loadActionHandler();
        window._uxopianAI.openChat(window._uxopianAI.buildChatRequest());
        await flushPromises();

        window.ecm.model.Request.invokePluginService.mockImplementation((pluginId, serviceId, options) => {
            options.requestCompleteCallback({ token: 'second-token' });
        });
        await window.fetch(CONFIGURED_HOST + '/api/something');

        expect(fetchMock).toHaveBeenCalledTimes(1);
        const [, init] = fetchMock.mock.calls[0];
        expect(init.headers.Authorization).toBe('Bearer second-token');
    });

    it('opens the admin console using the host fetched from the plugin service (op=config)', async () => {
        mockProxyService({ config: { uxopianAiHost: CONFIGURED_HOST }, 'admin-token': { token: 'test-admin-token' } });
        window.open = jest.fn();

        loadActionHandler();
        window._uxopianAI.openAdmin();
        await flushPromises();

        expect(window.open).toHaveBeenCalledTimes(1);
        const openedUrl = window.open.mock.calls[0][0];
        expect(openedUrl.startsWith('https://configured.example.com/gui/gateway/auth/login')).toBe(true);
        expect(openedUrl).toContain('token=test-admin-token');
        expect(openedUrl).toContain('redirect=' + encodeURIComponent('/gui/gateway/uxopian-ai/filenet/admin/'));
    });

    it('does not open the admin console when the plugin service returns no configuration', async () => {
        mockProxyService({ config: {}, 'admin-token': { token: 'test-admin-token' } });
        window.open = jest.fn();
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

        loadActionHandler();
        window._uxopianAI.openAdmin();
        await flushPromises();

        expect(window.open).not.toHaveBeenCalled();
        expect(consoleErrorSpy).toHaveBeenCalledWith(
            '[Uxopian AI] Failed to open admin:',
            expect.objectContaining({ message: expect.stringContaining('not configured') })
        );

        consoleErrorSpy.mockRestore();
    });
});
