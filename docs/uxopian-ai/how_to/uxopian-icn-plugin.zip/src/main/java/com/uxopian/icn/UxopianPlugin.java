package com.uxopian.icn;

import com.ibm.ecm.extension.Plugin;
import com.ibm.ecm.extension.PluginAction;
import com.ibm.ecm.extension.PluginService;

import java.util.Locale;

public class UxopianPlugin extends Plugin {

    @Override
    public String getId() {
        return "UxopianPlugin";
    }

    @Override
    public String getName(Locale locale) {
        return "Uxopian Plugin";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }

    @Override
    public String getScript() {
        // getResource/actionHandler.js → WebContent/actionHandler.js dans le JAR
        return "actionHandler.js";
    }

    @Override
    public String getDojoModule() {
        // ICN enregistre le package Dojo "uxopianPluginDojo" → WebContent/
        // require("uxopianPluginDojo/actionHandler") → WebContent/actionHandler.js ✓
        return "uxopianPluginDojo";
    }

    @Override
    public PluginAction[] getActions() {
        return new PluginAction[] { new UxopianAction() };
    }

    @Override
    public PluginService[] getServices() {
        return new PluginService[] { new UxopianProxyService() };
    }
}
