package com.uxopian.icn;

import java.util.Locale;

import com.ibm.ecm.extension.PluginFeature;

public class UxopianFeature extends PluginFeature {

    @Override
    public String getId() {
        return "UxopianFeature";
    }

    @Override
    public String getName(Locale locale) {
        return "IA Chat";
    }

    @Override
    public String getDescription(Locale locale) {
        return "Open Xopia chat window";
    }

    @Override
    public String getIconUrl() {
        return "icon.svg";
    }

    @Override
    public String getFeatureIconTooltipText(Locale locale) {
        return "Xopia Chat";
    }

    @Override
    public String getPopupWindowTooltipText(Locale locale) {
        return "";
    }

    @Override
    public String getContentClass() {
        return "uxopianPluginDojo.ChatFeature";
    }

    @Override
    public String getPopupWindowClass() {
        return "";
    }

    @Override
    public boolean isPreLoad() {
        return false;
    }
}
