package com.uxopian.icn;

import java.util.Locale;

import com.ibm.ecm.extension.PluginAction;

public class UxopianAction extends PluginAction
{

    @Override
    public String getId()
    {
        return "UxopianAction";
    }

    @Override
    public String getName(Locale locale)
    {
        return "Uxopian AI";
    }

    @Override
    public String getIcon()
    {
        return "";
    }

    @Override
    public String getPrivilege()
    {
        return "";
    }

    @Override
    public boolean isMultiDoc()
    {
        return true;
    }

    @Override
    public String getActionFunction()
    {
        return "uxopianPluginDojo/actionHandler";
    }

    @Override
    public String getServerTypes()
    {
        return "p8";
    }
}
