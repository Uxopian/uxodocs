package com.uxopian.icn;

import com.ibm.ecm.extension.PluginAction;

import java.util.Locale;

public class UxopianAction extends PluginAction {

    @Override
    public String getId() {
        return "UxopianAction";
    }

    @Override
    public String getName(Locale locale) {
        return "Ouvrir dans Uxopian";
    }

    @Override
    public String getIcon() {
        // Laisser vide = icône par défaut de FileNet
        return "";
    }

    @Override
    public String getPrivilege() {
        // Aucun privilège spécifique requis
        return "";
    }

    @Override
    public boolean isMultiDoc() {
        return false;
    }

    @Override
    public String getActionFunction() {
        // Chemin de module Dojo (slashes) = WebContent/uxopianPluginDojo/actionHandler.js
        return "uxopianPluginDojo/actionHandler";
    }

    @Override
    public String getServerTypes() {
        // "p8" = FileNet P8, "cm" = CM8, "od" = OnDemand, "" = tous
        return "p8";
    }
}
