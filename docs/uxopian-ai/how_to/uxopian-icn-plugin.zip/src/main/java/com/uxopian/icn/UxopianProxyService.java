package com.uxopian.icn;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.Principal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.ecm.configuration.DesktopConfig;
import com.ibm.ecm.configuration.RepositoryConfig;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;
import com.ibm.json.java.JSONObject;
import com.uxopian.icn.jwt.JwtSigner;
import com.uxopian.icn.jwt.KeystoreLoader;

public class UxopianProxyService extends PluginService
{

    private static final Logger LOGGER = Logger.getLogger(UxopianProxyService.class.getName());

    private static final String PROP_KEYSTORE_PATH = "icn.plugin.keystore.path";

    private static final String PROP_KEYSTORE_ALIAS = "icn.plugin.keystore.alias";

    private static final String PROP_KEYSTORE_PASSWORD = "icn.plugin.keystore.password";

    private static final String PROP_BFF_URL = "icn.plugin.bff.url";

    private static final String DEFAULT_BFF_URL = "http://localhost:8085/gui/gateway/uxopian-ai-filenet-icn";

    private static final List<String> ADMIN_ROLES = Collections.singletonList("ADMIN");

    private static final int CONNECT_TIMEOUT_MILLIS = 10_000;

    private static final int READ_TIMEOUT_MILLIS = 60_000;

    private static final Set<String> HOP_BY_HOP_HEADERS = new HashSet<>(Arrays.asList("connection", "transfer-encoding",
            "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailers", "upgrade"));

    private static final Set<String> FORWARDED_HEADERS = new HashSet<>(
            Arrays.asList("content-type", "accept", "accept-encoding", "accept-language", "cache-control"));

    private volatile KeystoreLoader keystoreLoader;

    private final Object initLock = new Object();

    @Override
    public String getId()
    {
        return "UxopianProxyService";
    }

    @Override
    public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        String op = request.getParameter("op");

        switch (op != null ? op : "")
        {
            case "public-key":
                servePublicKey(response);
                return;
            case "token":
                serveToken(callbacks, request, response, Collections.<String> emptyList());
                return;
            case "admin-token":
                serveToken(callbacks, request, response, ADMIN_ROLES);
                return;
            case "config":
                serveConfig(callbacks, response);
                return;
            default:
                proxyToBff(callbacks, request, response);
        }
    }

    private void proxyToBff(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        String bffBase = System.getProperty(PROP_BFF_URL, DEFAULT_BFF_URL);
        String jwt = JwtSigner.sign(callbacks.getUserId(), Collections.<String> emptyList(),
                resolveObjectStore(callbacks, request), getKeystoreLoader().getPrivateKey());

        proxyRequest(request, response, bffBase + resolvePath(request), jwt);
    }

    private void serveToken(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response,
            List<String> roles) throws Exception
    {
        JSONResponse jsonResponse = new JSONResponse();
        try
        {
            String userId = resolveUserId(callbacks, request);
            String jwt = JwtSigner.sign(userId, roles, resolveObjectStore(callbacks, request),
                    getKeystoreLoader().getPrivateKey());
            jsonResponse.put("token", jwt);
        }
        catch (Exception e)
        {
            LOGGER.log(Level.SEVERE, "Failed to sign a token with roles " + roles, e);
            jsonResponse.put("error", errorMessage(e));
        }
        callbacks.writeJSONResponse(jsonResponse, response);
    }

    private void serveConfig(PluginServiceCallbacks callbacks, HttpServletResponse response) throws Exception
    {
        JSONResponse jsonResponse = new JSONResponse();
        try
        {
            String raw = callbacks.loadConfiguration();
            if (raw != null && !raw.isEmpty())
            {
                Object host = JSONObject.parse(raw).get("uxopianAiHost");
                if (host != null)
                {
                    jsonResponse.put("uxopianAiHost", host);
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.log(Level.SEVERE, "serveConfig failed", e);
            jsonResponse.put("error", errorMessage(e));
        }
        callbacks.writeJSONResponse(jsonResponse, response);
    }

    private void servePublicKey(HttpServletResponse response) throws IOException
    {
        try
        {
            String pem = getKeystoreLoader().getPublicKeyPem();
            response.setContentType("text/plain;charset=UTF-8");
            response.getWriter().write(pem);
        }
        catch (Exception e)
        {
            LOGGER.log(Level.SEVERE, "Failed to serve public key", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Key unavailable");
        }
    }

    private String resolveUserId(PluginServiceCallbacks callbacks, HttpServletRequest request)
    {
        try
        {
            String userId = callbacks.getUserId();
            if (userId != null && !userId.isEmpty())
            {
                return userId;
            }
        }
        catch (Exception e)
        {
            LOGGER.log(Level.FINE, "callbacks.getUserId() failed, falling back to the request principal", e);
        }
        Principal principal = request.getUserPrincipal();
        return principal != null ? principal.getName() : "anonymous";
    }

    private String resolveObjectStore(PluginServiceCallbacks callbacks, HttpServletRequest request)
    {
        try
        {
            DesktopConfig desktop = callbacks.getConfigInterface().getDesktopConfig(request);
            if (desktop == null)
            {
                LOGGER.warning("No desktop configuration resolved for this request, tenant claim omitted");
                return null;
            }
            String requestedRepositoryId = callbacks.getRepositoryId();
            boolean requestedIsExposedByDesktop = requestedRepositoryId != null
                    && desktop.hasRepository(requestedRepositoryId);
            String repositoryId = requestedIsExposedByDesktop ? requestedRepositoryId
                    : desktop.getDefaultRepositoryId();

            RepositoryConfig repository = repositoryId != null ? desktop.getRepository(repositoryId) : null;
            if (repository == null)
            {
                LOGGER.warning("No repository resolved on desktop, tenant claim omitted");
                return null;
            }
            String objectStore = repository.getObjectStore();
            LOGGER.info("Resolved object store '" + objectStore + "' from repository '" + repositoryId + "'");
            return objectStore;
        }
        catch (Exception e)
        {
            LOGGER.log(Level.WARNING, "Failed to resolve the object store, tenant claim omitted", e);
            return null;
        }
    }

    private void proxyRequest(HttpServletRequest request, HttpServletResponse response, String url, String jwt)
            throws IOException
    {
        String query = request.getQueryString();
        String targetUrl = (query != null && !query.isEmpty()) ? url + "?" + query : url;
        String method = request.getMethod();

        HttpURLConnection connection = (HttpURLConnection) new URL(targetUrl).openConnection();
        try
        {
            connection.setRequestMethod(method);
            connection.setConnectTimeout(CONNECT_TIMEOUT_MILLIS);
            connection.setReadTimeout(READ_TIMEOUT_MILLIS);
            connection.setDoInput(true);
            connection.setInstanceFollowRedirects(true);

            connection.setRequestProperty("Authorization", "Bearer " + jwt);
            connection.setRequestProperty("X-Provider-ID", "IcnJwtProvider");

            for (String header : Collections.list(request.getHeaderNames()))
            {
                if (FORWARDED_HEADERS.contains(header.toLowerCase(Locale.ROOT)))
                {
                    connection.setRequestProperty(header, request.getHeader(header));
                }
            }

            if (hasRequestBody(method))
            {
                connection.setDoOutput(true);
                copy(request.getInputStream(), connection.getOutputStream());
            }

            connection.connect();

            int status = connection.getResponseCode();
            response.setStatus(status);
            copyResponseHeaders(connection, response);

            InputStream body = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (body != null)
            {
                copy(body, response.getOutputStream());
            }
        }
        finally
        {
            connection.disconnect();
        }
    }

    private static void copyResponseHeaders(HttpURLConnection connection, HttpServletResponse response)
    {
        for (Map.Entry<String, List<String>> header : connection.getHeaderFields().entrySet())
        {
            String name = header.getKey();
            if (name == null || HOP_BY_HOP_HEADERS.contains(name.toLowerCase(Locale.ROOT)))
            {
                continue;
            }
            for (String value : header.getValue())
            {
                response.addHeader(name, value);
            }
        }
    }

    private static boolean hasRequestBody(String method)
    {
        return "POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method) || "PATCH".equalsIgnoreCase(method);
    }

    private String resolvePath(HttpServletRequest request)
    {
        String pathInfo = request.getPathInfo();
        if (pathInfo != null && !pathInfo.isEmpty())
        {
            return pathInfo;
        }
        String marker = "/" + getId();
        String uri = request.getRequestURI();
        int markerIndex = uri.indexOf(marker);
        if (markerIndex < 0)
        {
            return "/";
        }
        String rest = uri.substring(markerIndex + marker.length());
        return rest.isEmpty() ? "/" : rest;
    }

    private static String errorMessage(Exception e)
    {
        return e.getMessage() != null ? e.getMessage() : e.getClass().getName();
    }

    private static void copy(InputStream in, OutputStream out) throws IOException
    {
        byte[] buffer = new byte[8192];
        int read;
        while ((read = in.read(buffer)) != -1)
        {
            out.write(buffer, 0, read);
        }
        out.flush();
    }

    private KeystoreLoader getKeystoreLoader() throws Exception
    {
        if (keystoreLoader == null)
        {
            synchronized (initLock)
            {
                if (keystoreLoader == null)
                {
                    String path = System.getProperty(PROP_KEYSTORE_PATH, "icn-plugin.p12");
                    String alias = System.getProperty(PROP_KEYSTORE_ALIAS, "icn-plugin");
                    String password = System.getProperty(PROP_KEYSTORE_PASSWORD, "changeit");
                    keystoreLoader = new KeystoreLoader(path, alias, password);
                    LOGGER.info("UxopianProxyService: keystore loaded from " + path);
                }
            }
        }
        return keystoreLoader;
    }
}
