package com.uxopian.icn;

import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;
import com.uxopian.icn.jwt.JwtSigner;
import com.uxopian.icn.jwt.KeystoreLoader;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UxopianProxyService extends PluginService {

    private static final Logger LOGGER = Logger.getLogger(UxopianProxyService.class.getName());

    private static final String PROP_KEYSTORE_PATH     = "icn.plugin.keystore.path";
    private static final String PROP_KEYSTORE_ALIAS    = "icn.plugin.keystore.alias";
    private static final String PROP_KEYSTORE_PASSWORD = "icn.plugin.keystore.password";
    private static final String PROP_BFF_URL           = "icn.plugin.bff.url";

    private static final Set<String> HOP_BY_HOP_HEADERS = new HashSet<>(Arrays.asList(
            "connection", "transfer-encoding", "keep-alive", "proxy-authenticate",
            "proxy-authorization", "te", "trailers", "upgrade"
    ));

    private volatile KeystoreLoader keystoreLoader;
    private final Object initLock = new Object();

    @Override
    public String getId() {
        return "UxopianProxyService";
    }

    @Override
    public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        String op = request.getParameter("op");

        if ("public-key".equals(op)) {
            servePublicKey(response);
            return;
        }

        if ("token".equals(op)) {
            serveToken(callbacks, request, response);
            return;
        }

        if ("admin-token".equals(op)) {
            serveAdminToken(callbacks, request, response);
            return;
        }

        String pathInfo = resolvePath(request);

        String bffBase = System.getProperty(PROP_BFF_URL, "http://localhost:8085/gui/gateway/uxopian-ai-filenet-icn");
        String userId = callbacks.getUserId();
        String jwt = JwtSigner.sign(userId, Collections.<String>emptyList(), getKeystoreLoader().getPrivateKey());

        proxyRequest(request, response, bffBase + pathInfo, jwt);
    }

    private void serveToken(PluginServiceCallbacks callbacks, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        JSONResponse jsonResponse = new JSONResponse();
        try {
            String userId = resolveUserId(callbacks, request);
            String jwt = JwtSigner.sign(userId, Collections.<String>emptyList(), getKeystoreLoader().getPrivateKey());
            jsonResponse.put("token", jwt);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "serveToken failed", e);
            String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getName();
            jsonResponse.put("error", msg);
        }
        callbacks.writeJSONResponse(jsonResponse, response);
    }

    private void serveAdminToken(PluginServiceCallbacks callbacks, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        JSONResponse jsonResponse = new JSONResponse();
        try {
            String userId = resolveUserId(callbacks, request);
            String jwt = JwtSigner.sign(userId, Collections.singletonList("ADMIN"), getKeystoreLoader().getPrivateKey());
            jsonResponse.put("token", jwt);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "serveAdminToken failed", e);
            String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getName();
            jsonResponse.put("error", msg);
        }
        callbacks.writeJSONResponse(jsonResponse, response);
    }

    private String resolveUserId(PluginServiceCallbacks callbacks, HttpServletRequest request) {
        try {
            String id = callbacks.getUserId();
            if (id != null && !id.isEmpty()) { return id; }
        } catch (Exception ignored) {}
        java.security.Principal p = request.getUserPrincipal();
        return (p != null) ? p.getName() : "anonymous";
    }

    private void servePublicKey(HttpServletResponse response) throws IOException {
        try {
            String pem = getKeystoreLoader().getPublicKeyPem();
            response.setContentType("text/plain;charset=UTF-8");
            response.getWriter().write(pem);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to serve public key", e);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Key unavailable");
        }
    }

    private void proxyRequest(HttpServletRequest request, HttpServletResponse response,
            String targetUrl, String jwt) throws IOException {
        String query = request.getQueryString();
        if (query != null && !query.isEmpty()) {
            targetUrl = targetUrl + "?" + query;
        }

        HttpURLConnection conn = (HttpURLConnection) new URL(targetUrl).openConnection();
        try {
            conn.setRequestMethod(request.getMethod());
            conn.setConnectTimeout(10_000);
            conn.setReadTimeout(60_000);
            conn.setDoInput(true);
            conn.setInstanceFollowRedirects(true);

            conn.setRequestProperty("Authorization", "Bearer " + jwt);
            conn.setRequestProperty("X-Provider-ID", "IcnJwtProvider");

            for (String header : Collections.list(request.getHeaderNames())) {
                if (shouldForward(header)) {
                    conn.setRequestProperty(header, request.getHeader(header));
                }
            }

            String method = request.getMethod();
            if ("POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method) || "PATCH".equalsIgnoreCase(method)) {
                conn.setDoOutput(true);
                copy(request.getInputStream(), conn.getOutputStream());
            }

            conn.connect();

            int status = conn.getResponseCode();
            response.setStatus(status);

            conn.getHeaderFields().forEach((key, values) -> {
                if (key == null) return;
                if (HOP_BY_HOP_HEADERS.contains(key.toLowerCase())) return;
                for (String v : values) {
                    response.addHeader(key, v);
                }
            });

            InputStream body = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (body != null) {
                copy(body, response.getOutputStream());
            }
        } finally {
            conn.disconnect();
        }
    }

    private boolean shouldForward(String headerName) {
        String lower = headerName.toLowerCase();
        return lower.equals("content-type")
                || lower.equals("accept")
                || lower.equals("accept-encoding")
                || lower.equals("accept-language")
                || lower.equals("cache-control");
    }

    private String resolvePath(HttpServletRequest request) {
        String pathInfo = request.getPathInfo();
        if (pathInfo != null && !pathInfo.isEmpty()) {
            return pathInfo;
        }
        String uri = request.getRequestURI();
        String marker = "/" + getId();
        int idx = uri.indexOf(marker);
        if (idx >= 0) {
            String rest = uri.substring(idx + marker.length());
            return rest.isEmpty() ? "/" : rest;
        }
        return "/";
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
        out.flush();
    }

    private KeystoreLoader getKeystoreLoader() throws Exception {
        if (keystoreLoader == null) {
            synchronized (initLock) {
                if (keystoreLoader == null) {
                    String path     = System.getProperty(PROP_KEYSTORE_PATH, "icn-plugin.p12");
                    String alias    = System.getProperty(PROP_KEYSTORE_ALIAS, "icn-plugin");
                    String password = System.getProperty(PROP_KEYSTORE_PASSWORD, "changeit");
                    keystoreLoader = new KeystoreLoader(path, alias, password);
                    LOGGER.info("UxopianProxyService: keystore loaded from " + path);
                }
            }
        }
        return keystoreLoader;
    }
}
