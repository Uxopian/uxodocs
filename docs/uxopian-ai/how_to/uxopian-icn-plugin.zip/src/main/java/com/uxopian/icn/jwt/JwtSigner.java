package com.uxopian.icn.jwt;

import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.Base64;
import java.util.List;

public final class JwtSigner
{

    private static final String HEADER_B64 = base64url(
            "{\"alg\":\"RS256\",\"typ\":\"JWT\"}".getBytes(StandardCharsets.UTF_8));

    private static final String ISSUER = "icn-plugin";

    private static final long TTL_SECONDS = 30L;

    private JwtSigner()
    {
    }

    public static String sign(String userId, List<String> roles, String tenantId, PrivateKey privateKey)
            throws Exception
    {
        long issuedAt = System.currentTimeMillis() / 1000L;
        String payload = buildPayload(userId, roles, tenantId, issuedAt);
        String signingInput = HEADER_B64 + "." + base64url(payload.getBytes(StandardCharsets.UTF_8));

        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(signingInput.getBytes(StandardCharsets.UTF_8));

        return signingInput + "." + base64url(signature.sign());
    }

    private static String buildPayload(String userId, List<String> roles, String tenantId, long issuedAt)
    {
        StringBuilder payload = new StringBuilder("{\"sub\":\"").append(escape(userId)).append("\"")
                .append(",\"iss\":\"").append(ISSUER).append("\"").append(",\"iat\":").append(issuedAt)
                .append(",\"exp\":").append(issuedAt + TTL_SECONDS).append(",\"roles\":").append(toJsonArray(roles));
        if (tenantId != null && !tenantId.isEmpty())
        {
            payload.append(",\"tenantId\":\"").append(escape(tenantId)).append("\"");
        }
        return payload.append("}").toString();
    }

    private static String base64url(byte[] data)
    {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(data);
    }

    private static String escape(String value)
    {
        if (value == null)
        {
            return "";
        }
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String toJsonArray(List<String> items)
    {
        if (items == null || items.isEmpty())
        {
            return "[]";
        }
        StringBuilder array = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++)
        {
            if (i > 0)
            {
                array.append(",");
            }
            array.append("\"").append(escape(items.get(i))).append("\"");
        }
        return array.append("]").toString();
    }
}
