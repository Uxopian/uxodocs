package com.uxopian.icn.jwt;

import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.Base64;
import java.util.List;

public final class JwtSigner
{

    private static final String HEADER_B64 = base64url(
            "{\"alg\":\"RS256\",\"typ\":\"JWT\"}".getBytes(StandardCharsets.UTF_8));

    private static final String ISSUER = "icn-plugin";

    private static final long TTL_SECONDS = 30L;

    private JwtSigner()
    {
    }

    public static String sign(String userId, List<String> roles, PrivateKey privateKey) throws Exception
    {
        long now = System.currentTimeMillis() / 1000L;
        String payload = buildPayload(userId, roles, now, now + TTL_SECONDS);
        String payloadB64 = base64url(payload.getBytes(StandardCharsets.UTF_8));

        String signingInput = HEADER_B64 + "." + payloadB64;
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(privateKey);
        sig.update(signingInput.getBytes(StandardCharsets.UTF_8));

        return signingInput + "." + base64url(sig.sign());
    }

    private static String buildPayload(String userId, List<String> roles, long iat, long exp)
    {
        return "{\"sub\":\"" + escape(userId) + "\"" + ",\"iss\":\"" + ISSUER + "\"" + ",\"iat\":" + iat + ",\"exp\":"
                + exp + ",\"roles\":" + toJsonArray(roles) + "}";
    }

    private static String base64url(byte[] data)
    {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(data);
    }

    private static String escape(String s)
    {
        if (s == null)
            return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String toJsonArray(List<String> items)
    {
        if (items == null || items.isEmpty())
            return "[]";
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++)
        {
            if (i > 0)
                sb.append(",");
            sb.append("\"").append(escape(items.get(i))).append("\"");
        }
        return sb.append("]").toString();
    }
}
