package com.uxopian.icn.jwt;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

public class KeystoreLoader
{

    private static final String RESOURCE_PACKAGE = "/com/uxopian/icn/";

    private final PrivateKey privateKey;

    private final PublicKey publicKey;

    public KeystoreLoader(String p12Path, String alias, String password) throws Exception
    {
        char[] secret = password.toCharArray();
        KeyStore keystore = loadKeystoreTryingEveryKnownFormat(p12Path, secret);
        this.privateKey = (PrivateKey) keystore.getKey(alias, secret);
        if (this.privateKey == null)
        {
            throw new IllegalArgumentException("Alias '" + alias + "' not found or has no private key in " + p12Path);
        }
        this.publicKey = keystore.getCertificate(alias).getPublicKey();
    }

    public PrivateKey getPrivateKey()
    {
        return privateKey;
    }

    public PublicKey getPublicKey()
    {
        return publicKey;
    }

    public String getPublicKeyPem()
    {
        String base64 = Base64.getMimeEncoder(64, new byte[] { '\n' }).encodeToString(publicKey.getEncoded());
        return "-----BEGIN PUBLIC KEY-----\n" + base64 + "\n-----END PUBLIC KEY-----";
    }

    private static KeyStore loadKeystoreTryingEveryKnownFormat(String path, char[] password) throws Exception
    {
        Exception pkcs12Failure;
        try
        {
            return load("PKCS12", null, path, password);
        }
        catch (Exception e)
        {
            pkcs12Failure = e;
        }

        Exception ibmFailure;
        try
        {
            return load("PKCS12", "IBMJCE", path, password);
        }
        catch (Exception e)
        {
            ibmFailure = e;
        }

        try
        {
            return load("JKS", null, replaceExtension(path, ".jks"), password);
        }
        catch (Exception jksFailure)
        {
            throw new Exception("Cannot load keystore '" + path + "': PKCS12=" + pkcs12Failure.getMessage()
                    + ", IBMJCE=" + ibmFailure.getMessage() + ", JKS=" + jksFailure.getMessage(), jksFailure);
        }
    }

    private static KeyStore load(String type, String provider, String path, char[] password) throws Exception
    {
        try (InputStream stream = openKeystore(path))
        {
            KeyStore keystore = provider == null ? KeyStore.getInstance(type) : KeyStore.getInstance(type, provider);
            keystore.load(stream, password);
            return keystore;
        }
    }

    private static InputStream openKeystore(String path) throws IOException
    {
        if (!Files.exists(Paths.get(path)))
        {
            InputStream fromClasspath = KeystoreLoader.class.getResourceAsStream(RESOURCE_PACKAGE + path);
            if (fromClasspath == null)
            {
                fromClasspath = KeystoreLoader.class.getResourceAsStream("/" + path);
            }
            if (fromClasspath != null)
            {
                return fromClasspath;
            }
        }
        return new FileInputStream(path);
    }

    private static String replaceExtension(String path, String extension)
    {
        return path.replaceAll("\\.[^.]+$", "") + extension;
    }
}
