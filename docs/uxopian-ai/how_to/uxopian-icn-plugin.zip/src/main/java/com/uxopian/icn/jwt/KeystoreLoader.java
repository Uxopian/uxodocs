package com.uxopian.icn.jwt;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

public class KeystoreLoader {

    private final PrivateKey privateKey;
    private final PublicKey publicKey;

    public KeystoreLoader(String p12Path, String alias, String password) throws Exception {
        KeyStore ks = loadKeystore(p12Path, password.toCharArray());
        this.privateKey = (PrivateKey) ks.getKey(alias, password.toCharArray());
        if (this.privateKey == null) {
            throw new IllegalArgumentException("Alias '" + alias + "' not found or has no private key in " + p12Path);
        }
        this.publicKey = ks.getCertificate(alias).getPublicKey();
    }

    private static KeyStore loadKeystore(String path, char[] password) throws Exception {
        // 1. PKCS12 provider par défaut
        try (InputStream is = openKeystore(path)) {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(is, password);
            return ks;
        } catch (Exception e1) {
            // 2. PKCS12 provider IBMJCE (WebSphere / IBM Java 8)
            try (InputStream is = openKeystore(path)) {
                KeyStore ks = KeyStore.getInstance("PKCS12", "IBMJCE");
                ks.load(is, password);
                return ks;
            } catch (Exception e2) {
                // 3. JKS — format compatible IBM Java 8 (icn-plugin.jks embarqué dans le JAR)
                String jksPath = path.replaceAll("\\.[^.]+$", "") + ".jks";
                try (InputStream is = openKeystore(jksPath)) {
                    KeyStore ks = KeyStore.getInstance("JKS");
                    ks.load(is, password);
                    return ks;
                } catch (Exception e3) {
                    throw new Exception("Cannot load keystore '" + path + "': PKCS12=" + e1.getMessage()
                        + ", IBMJCE=" + e2.getMessage() + ", JKS=" + e3.getMessage(), e3);
                }
            }
        }
    }

    private static InputStream openKeystore(String path) throws Exception {
        if (Files.exists(Paths.get(path))) {
            return new FileInputStream(path);
        }
        InputStream cp = KeystoreLoader.class.getResourceAsStream("/com/uxopian/icn/" + path);
        if (cp != null) { return cp; }
        cp = KeystoreLoader.class.getResourceAsStream("/" + path);
        if (cp != null) { return cp; }
        // Dernier recours : fichier absolu ou relatif au classpath racine
        return new FileInputStream(path);
    }

    public PrivateKey getPrivateKey() {
        return privateKey;
    }

    public PublicKey getPublicKey() {
        return publicKey;
    }

    public String getPublicKeyPem() {
        byte[] encoded = publicKey.getEncoded();
        String b64 = Base64.getMimeEncoder(64, new byte[]{'\n'}).encodeToString(encoded);
        return "-----BEGIN PUBLIC KEY-----\n" + b64 + "\n-----END PUBLIC KEY-----";
    }
}
