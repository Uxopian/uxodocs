package com.uxopian.icn;

import java.io.IOException;

import com.ibm.json.java.JSONObject;

public class PluginConfiguration
{
    private final String uxopianAiHost;

    private final String scripts;

    public PluginConfiguration(String uxopianAiHost, String scripts)
    {
        this.uxopianAiHost = uxopianAiHost;
        this.scripts = scripts;
    }

    public static PluginConfiguration parse(String raw) throws IOException
    {
        if (raw == null || raw.isEmpty())
        {
            return new PluginConfiguration(null, null);
        }
        JSONObject json = JSONObject.parse(raw);
        return new PluginConfiguration((String) json.get("uxopianAiHost"), (String) json.get("scripts"));
    }

    public String getUxopianAiHost()
    {
        return uxopianAiHost;
    }

    public String getScripts()
    {
        return scripts;
    }
}
