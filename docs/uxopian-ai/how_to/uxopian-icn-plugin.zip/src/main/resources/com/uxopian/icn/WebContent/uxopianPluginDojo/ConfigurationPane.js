define([
    "dojo/_base/declare",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "ecm/widget/admin/PluginConfigurationPane",
    "dojo/text!./ConfigurationPane.html"
], function (declare, _TemplatedMixin, _WidgetsInTemplateMixin, PluginConfigurationPane, template) {

    return declare("uxopianPluginDojo.ConfigurationPane", [PluginConfigurationPane, _TemplatedMixin, _WidgetsInTemplateMixin], {

        templateString: template,
        widgetsInTemplate: true,

        load: function (callback) {
            if (this.configurationString) {
                try {
                    var config = JSON.parse(this.configurationString);
                    if (config.uxopianAiHost) {
                        this.uxopianAiHostField.set("value", config.uxopianAiHost);
                    }
                } catch (e) {
                    console.error("[Uxopian AI] Failed to parse configuration:", e);
                }
            }
            if (callback) { callback(); }
        },

        _onFieldChange: function () {
            var config = {
                uxopianAiHost: this.uxopianAiHostField.get("value")
            };
            this.configurationString = JSON.stringify(config);
            this.onSaveNeeded(true);
        },

        validate: function () {
            return this.uxopianAiHostField.isValid();
        }
    });
});
