define(['dojo/_base/declare'], function (declare) {
    return declare(null, {
        run: function (repository, items, callback) {
            var ai = window._uxopianAI;
            ai.openChat(ai.buildChatRequest());
            if (callback) { callback(); }
        }
    });
});
