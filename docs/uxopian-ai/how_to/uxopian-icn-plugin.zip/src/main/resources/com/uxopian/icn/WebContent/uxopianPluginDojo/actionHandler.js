define(['dojo/_base/declare'], function (declare) {
    return declare(null, {
        run: function (repository, items, callback) {
            window._uxopianAI.showActions(items);
            if (callback) { callback(); }
        }
    });
});
