(function () {
    var PLUGIN_ID = 'UxopianPlugin';
    var SERVICE_ID = 'UxopianProxyService';
    var CHAT_BUTTON_ID = 'uxopian-ai-navbar-btn';
    var ADMIN_BUTTON_ID = 'uxopian-ai-admin-btn';
    var MAX_INJECT_RETRIES = 60;
    var INJECT_RETRY_DELAY_MS = 300;

    var ACTIONS_MENU_ID = 'uxopian-ai-actions-menu';
    var MENU_ACTION_ID = 'UxopianAI';
    var PLUGIN_ACTION_ID = 'UxopianAction';
    var DOCUMENT_AND_FOLDER_MENUS = [
        'ItemContextMenu',
        'FolderContextMenu',
        'ContentListToolbar',
        'FavoriteItemContextMenu',
        'FavoriteFolderContextMenu',
        'TeamspaceItemContextMenu',
        'TeamspaceFolderContextMenu',
        'TeamspaceSubFolderContextMenu',
        'TeamspaceContentListToolbar',
        'WorkItemDocumentContextMenu',
        'WorkItemFolderContextMenu'
    ];

    var _assetsPromise = null;
    var _configPromise = null;
    var _scriptContents = {};
    var _runningScriptId = null;
    var _interceptorInstalled = false;
    var _actions = [];
    var _closeActionsMenu = null;
    var _menuEntriesInstalled = false;
    var _refreshPromise = null;
    var _lastPointer = { x: 0, y: 0 };

    function invokeProxyService(op) {
        return new Promise(function (resolve, reject) {
            ecm.model.Request.invokePluginService(PLUGIN_ID, SERVICE_ID, {
                requestParams: { op: op },
                requestCompleteCallback: resolve,
                requestErrorCallback: function (e) {
                    reject(new Error('invokePluginService error: ' + JSON.stringify(e)));
                }
            });
        });
    }

    function fetchConfig(isRefreshed) {
        if (!_configPromise || isRefreshed) {
            _configPromise = invokeProxyService('config')
                .then(function (r) {
                    if (!r || !r.uxopianAiHost) {
                        throw new Error('Uxopian AI Host URL is not configured. Set it in the ICN Admin '
                            + 'Console (Plug-ins > Uxopian Plugin > Configure).');
                    }
                    return r;
                })
                .catch(function (err) {
                    _configPromise = null;
                    return Promise.reject(err);
                });
        }
        return _configPromise;
    }

    function fetchUxopianHost() {
        return fetchConfig().then(function (config) { return config.uxopianAiHost; });
    }

    function fetchToken(op) {
        return invokeProxyService(op).then(function (r) {
            if (!r || !r.token) {
                throw new Error('Missing token: ' + JSON.stringify(r));
            }
            return r.token;
        });
    }

    function getWsHost(host) {
        return host.replace('https://', 'wss://').replace('http://', 'ws://');
    }

    function injectCss(host) {
        if (document.querySelector('link[data-uxopian-css]')) { return; }
        var link = document.createElement('link');
        link.setAttribute('data-uxopian-css', '1');
        link.rel = 'stylesheet';
        link.href = host + '/api/web-components/chat/style';
        document.head.appendChild(link);
    }

    function injectScript(host) {
        return new Promise(function (resolve, reject) {
            if (document.querySelector('script[data-uxopian-js]')) { resolve(); return; }
            var script = document.createElement('script');
            script.setAttribute('data-uxopian-js', '1');
            script.onload = resolve;
            script.onerror = function () { reject(new Error('script load failed')); };
            script.src = host + '/api/web-components/chat/script';
            document.head.appendChild(script);
        });
    }

    function loadAssets(host) {
        if (typeof window.createChat === 'function') { return Promise.resolve(); }
        if (_assetsPromise) { return _assetsPromise; }
        injectCss(host);
        _assetsPromise = injectScript(host)
            .catch(function (err) { _assetsPromise = null; return Promise.reject(err); });
        return _assetsPromise;
    }

    // The token cannot be passed to createChat, so it is attached transparently. A fresh one per
    // request: a chat session routinely outlives the JWT's TTL.
    function installAuthInterceptor(host) {
        if (_interceptorInstalled) { return; }
        _interceptorInstalled = true;

        var NativeXHR = window.XMLHttpRequest;
        function PatchedXHR() {
            var xhr = new NativeXHR();
            var nativeOpen = xhr.open.bind(xhr);
            var nativeSend = xhr.send.bind(xhr);
            var targetsHost = false;
            xhr.open = function (method, url) {
                nativeOpen.apply(xhr, arguments);
                targetsHost = typeof url === 'string' && url.indexOf(host) === 0;
            };
            xhr.send = function (body) {
                if (!targetsHost) {
                    nativeSend(body);
                    return;
                }
                fetchToken('token').then(function (token) {
                    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
                    nativeSend(body);
                });
            };
            return xhr;
        }
        PatchedXHR.prototype = NativeXHR.prototype;
        window.XMLHttpRequest = PatchedXHR;

        var nativeFetch = window.fetch;
        window.fetch = function (input, init) {
            var url = typeof input === 'string' ? input : (input && input.url);
            if (!url || url.indexOf(host) !== 0) {
                return nativeFetch.call(this, input, init);
            }
            var self = this;
            return fetchToken('token').then(function (token) {
                var headers = Object.assign({}, init && init.headers, { 'Authorization': 'Bearer ' + token });
                return nativeFetch.call(self, input, Object.assign({}, init, { headers: headers }));
            });
        };
    }

    function openChat(request) {
        var host;
        fetchUxopianHost()
            .then(function (fetchedHost) {
                host = fetchedHost;
                return loadAssets(host);
            })
            .then(function () {
                installAuthInterceptor(host);
                if (typeof window.createChat !== 'function') {
                    console.error('[Uxopian AI] window.createChat not found.');
                    return;
                }
                window.createChat({ endpoint: host, wsEndpoint: getWsHost(host), request: request });
            })
            .catch(function (err) {
                console.error('[Uxopian AI] Failed to open chat:', err);
            });
    }

    function buildChatRequest() {
        return { inputs: [] };
    }

    function registerAction(action) {
        if (!action || !action.id || typeof action.onExecute !== 'function') {
            console.error('[Uxopian AI] An action needs an id and an onExecute function:', action);
            return;
        }
        var registered = Object.assign({}, action, { scriptId: _runningScriptId });
        _actions = _actions.filter(function (a) { return a.id !== action.id; }).concat([registered]);
    }

    function dropActionsOf(isDropped) {
        _actions = _actions.filter(function (a) { return !(a.scriptId && isDropped(a.scriptId)); });
    }

    function configuredScriptIds(config) {
        return String(config.scripts || '').split(',')
            .map(function (id) { return id.trim(); })
            .filter(function (id) { return id.length > 0; });
    }

    function runActionScript(id, content) {
        var previous = document.head.querySelector('script[data-uxopian-action-script="' + id + '"]');
        if (previous) {
            previous.parentNode.removeChild(previous);
        }
        dropActionsOf(function (scriptId) { return scriptId === id; });
        var script = document.createElement('script');
        script.setAttribute('data-uxopian-action-script', id);
        script.textContent = content;
        _runningScriptId = id;
        try {
            document.head.appendChild(script);
        } finally {
            _runningScriptId = null;
        }
        _scriptContents[id] = content;
    }

    // A <script src> cannot carry the bearer token, and ICN's CSP refuses blob: scripts while it allows
    // inline ones: the script is fetched through the interceptor, then run inline. It is revalidated on
    // every opening (a 304 while unchanged), so an edit in Uxopian AI shows without reloading ICN.
    function loadActionScript(host, id) {
        return window.fetch(host + '/api/v1/scripts/' + encodeURIComponent(id), { cache: 'no-cache' })
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('HTTP ' + response.status);
                }
                return response.text();
            })
            .then(function (content) {
                if (_scriptContents[id] !== content) {
                    runActionScript(id, content);
                }
            })
            .catch(function (err) {
                console.error('[Uxopian AI] Failed to load script ' + id + ':', err);
            });
    }

    function loadActionScripts(host, config) {
        var ids = configuredScriptIds(config);
        dropActionsOf(function (scriptId) { return ids.indexOf(scriptId) === -1; });
        Object.keys(_scriptContents).forEach(function (id) {
            if (ids.indexOf(id) === -1) {
                delete _scriptContents[id];
            }
        });
        return Promise.all(ids.map(function (id) { return loadActionScript(host, id); }));
    }

    function isFolder(item) {
        return typeof item.isFolder === 'function' ? item.isFolder() : item.mimetype === 'folder';
    }

    // A P8 item id reads "<class>,<object store id>,<object id>".
    function toFileNetObject(item) {
        var parts = String(item.id || '').split(',');
        return { objectId: parts[parts.length - 1], className: item.template || parts[0], name: item.name };
    }

    function buildActionContext(items) {
        var selected = items || [];
        var folderItem = selected.length === 1 && isFolder(selected[0]) ? selected[0] : null;
        var documents = folderItem ? [] : selected.filter(function (item) { return !isFolder(item); });
        return {
            folder: folderItem ? toFileNetObject(folderItem) : null,
            items: documents.map(function (item) {
                var document = toFileNetObject(item);
                document.mimeType = item.mimetype;
                return document;
            }),
            openChat: openChat
        };
    }

    function isApplicable(action, context) {
        if (context.folder) {
            return action.folder === true;
        }
        if (context.items.length === 0 || action.documents === false) {
            return false;
        }
        return context.items.length === 1 || action.multiDoc === true;
    }

    function closeActionsMenu() {
        if (_closeActionsMenu) {
            _closeActionsMenu();
        }
    }

    function runAction(action, context) {
        closeActionsMenu();
        try {
            action.onExecute(context);
        } catch (err) {
            console.error('[Uxopian AI] Action ' + action.id + ' failed:', err);
        }
    }

    function keepInViewport(menu) {
        var box = menu.getBoundingClientRect();
        if (box.right > window.innerWidth) {
            menu.style.left = Math.max(0, window.innerWidth - box.width) + 'px';
        }
        if (box.bottom > window.innerHeight) {
            menu.style.top = Math.max(0, window.innerHeight - box.height) + 'px';
        }
    }

    function renderActionsMenu(context) {
        closeActionsMenu();
        var menu = document.createElement('div');
        menu.id = ACTIONS_MENU_ID;
        menu.setAttribute('role', 'menu');
        menu.style.cssText = MENU_STYLE;

        var applicable = _actions.filter(function (action) { return isApplicable(action, context); });
        if (applicable.length === 0) {
            var empty = document.createElement('div');
            empty.style.cssText = 'padding:8px 12px;color:#525252';
            empty.textContent = 'No AI action for this selection';
            menu.appendChild(empty);
        }
        applicable.forEach(function (action) {
            var item = document.createElement('button');
            item.type = 'button';
            item.setAttribute('role', 'menuitem');
            item.style.cssText = MENU_ITEM_STYLE;
            item.textContent = action.label || action.id;
            item.onclick = function () { runAction(action, context); };
            menu.appendChild(item);
        });

        function onOutsideClick(e) {
            if (!menu.contains(e.target)) {
                closeActionsMenu();
            }
        }
        function onEscape(e) {
            if (e.key === 'Escape') {
                closeActionsMenu();
            }
        }
        _closeActionsMenu = function () {
            document.removeEventListener('mousedown', onOutsideClick, true);
            document.removeEventListener('keydown', onEscape, true);
            if (menu.parentNode) {
                menu.parentNode.removeChild(menu);
            }
            _closeActionsMenu = null;
        };
        document.addEventListener('mousedown', onOutsideClick, true);
        document.addEventListener('keydown', onEscape, true);
        menu.style.left = _lastPointer.x + 'px';
        menu.style.top = _lastPointer.y + 'px';
        document.body.appendChild(menu);
        keepInViewport(menu);

        var first = menu.querySelector('button');
        if (first) {
            first.focus();
        }
    }

    function refreshActions() {
        if (!_refreshPromise) {
            _refreshPromise = fetchConfig(true)
                .then(function (config) {
                    var host = config.uxopianAiHost;
                    return loadAssets(host).then(function () {
                        installAuthInterceptor(host);
                        return loadActionScripts(host, config);
                    });
                })
                .then(function () {
                    _refreshPromise = null;
                }, function (err) {
                    _refreshPromise = null;
                    return Promise.reject(err);
                });
        }
        return _refreshPromise;
    }

    function showActions(items) {
        return refreshActions()
            .then(function () {
                renderActionsMenu(buildActionContext(items));
            })
            .catch(function (err) {
                console.error('[Uxopian AI] Failed to show the AI actions:', err);
            });
    }

    function openAdmin() {
        fetchUxopianHost()
            .then(function (host) {
                // Anchored on the fixed /gui/gateway/ base: the number of segments after it varies
                // by route, so trimming a fixed number off the configured host would not work.
                var loginUrl = host.replace(/(\/gui\/gateway\/).*$/, '$1auth/login');
                var adminPath = (host + '/admin/').replace(/^https?:\/\/[^/]+/, '');
                return fetchToken('admin-token').then(function (token) {
                    var exchangeUrl = loginUrl
                        + '?providerId=FileNetProvider'
                        + '&token=' + encodeURIComponent(token)
                        + '&redirect=' + encodeURIComponent(adminPath);
                    (window.top || window).open(exchangeUrl, '_blank');
                });
            })
            .catch(function (err) {
                console.error('[Uxopian AI] Failed to open admin:', err);
            });
    }

    function isFolderMenu(menuType) {
        return menuType.indexOf('Folder') !== -1;
    }

    function toMenuAction(desktop, action, menuType) {
        var functionName = 'uxopianAiAction_' + action.id;
        var handler = desktop.getActionsHandler();
        if (handler) {
            handler[functionName] = function (repository, items) { runAction(action, buildActionContext(items)); };
        }
        return new ecm.model.Action({
            id: MENU_ACTION_ID + '_' + action.id,
            name: action.label || action.id,
            action: functionName,
            multiDoc: action.multiDoc === true,
            privileges: [],
            serverTypes: '',
            repositoryTypes: '',
            icon: '',
            subActions: [],
            menuType: menuType,
            submenuId: MENU_ACTION_ID
        });
    }

    // The submenu is rebuilt from the registered actions each time ICN shows the menu, so it follows the
    // scripts as they change.
    function addToMenu(desktop, menuType) {
        var actions = desktop.actionLists && desktop.actionLists[menuType];
        if (DOCUMENT_AND_FOLDER_MENUS.indexOf(menuType) === -1 || !actions) {
            return;
        }
        var placedByAdministrator = actions.some(function (action) {
            return action && action.id === PLUGIN_ACTION_ID;
        });
        var kept = actions.filter(function (action) { return !action || action.id !== MENU_ACTION_ID; });
        actions.length = 0;
        Array.prototype.push.apply(actions, kept);
        if (placedByAdministrator) {
            return;
        }
        var fitting = _actions.filter(function (action) {
            return isFolderMenu(menuType) ? action.folder === true : action.documents !== false;
        });
        if (fitting.length === 0) {
            return;
        }
        var subActions = fitting.map(function (action) { return toMenuAction(desktop, action, menuType); });
        actions.push(new ecm.model.Action({
            id: MENU_ACTION_ID,
            name: 'Uxopian AI',
            action: '',
            multiDoc: true,
            privileges: [],
            serverTypes: '',
            repositoryTypes: '',
            icon: '',
            subActions: subActions,
            actions: subActions,
            labelId: MENU_ACTION_ID,
            menuType: menuType
        }));
    }

    // ICN reads a menu from desktop.actionLists right after loadMenuActions, on every display: adding the
    // entry there puts it in every desktop without an administrator editing each desktop's menus. The
    // scripts are revalidated at the same time, for the next display.
    function installMenuEntries() {
        var desktop = window.ecm && ecm.model && ecm.model.desktop;
        if (_menuEntriesInstalled || !desktop || typeof desktop.loadMenuActions !== 'function') {
            return;
        }
        _menuEntriesInstalled = true;
        var loadMenuActions = desktop.loadMenuActions;
        desktop.loadMenuActions = function (menuType) {
            addToMenu(this, menuType);
            if (DOCUMENT_AND_FOLDER_MENUS.indexOf(menuType) !== -1) {
                refreshActions().catch(function (err) {
                    console.error('[Uxopian AI] Failed to refresh the AI actions:', err);
                });
            }
            return loadMenuActions.apply(this, arguments);
        };
    }

    window._uxopianAI = {
        openChat: openChat,
        buildChatRequest: buildChatRequest,
        openAdmin: openAdmin,
        showActions: showActions
    };
    window.UxopianAI = { registerAction: registerAction };

    var BTN_STYLE = [
        'display:inline-flex',
        'align-items:center',
        'gap:5px',
        'padding:4px 10px',
        'cursor:pointer',
        'color:inherit',
        'font-size:13px',
        'user-select:none',
        'vertical-align:middle'
    ].join(';');

    var MENU_STYLE = [
        'position:fixed',
        'z-index:10000',
        'min-width:220px',
        'padding:4px 0',
        'background:#fff',
        'border:1px solid #c6c6c6',
        'box-shadow:0 2px 8px rgba(0,0,0,0.2)',
        'font-size:13px'
    ].join(';');

    var MENU_ITEM_STYLE = [
        'display:block',
        'width:100%',
        'padding:8px 12px',
        'border:0',
        'background:none',
        'text-align:left',
        'cursor:pointer',
        'font:inherit',
        'color:#161616'
    ].join(';');

    var CHAT_ICON_PATH = 'M12 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22'
        + 'l4.832-1.438A9.953 9.953 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2z';

    var ADMIN_ICON_PATH = 'M12 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7zm7.43-2.97c.04-.32.07-.65.07-.98s-.03-.67-.07-1'
        + 'l2.11-1.63c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98'
        + 'l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98'
        + 'l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64L4.57 11c-.04.33-.07.65-.07.98'
        + 's.03.67.07 1l-2.11 1.63c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1'
        + 'c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42'
        + 'l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46'
        + 'c.12-.22.07-.49-.12-.64l-2.11-1.63z';

    function createNavbarButton(id, title, label, iconPath, onActivate) {
        var button = document.createElement('div');
        button.id = id;
        button.title = title;
        button.setAttribute('role', 'button');
        button.setAttribute('tabindex', '0');
        button.style.cssText = BTN_STYLE;
        button.innerHTML =
            '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" ' +
            'viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0">' +
            '<path d="' + iconPath + '"/>' +
            '</svg>' +
            '<span>' + label + '</span>';
        button.onclick = onActivate;
        button.onkeydown = function (e) {
            if (e.key === 'Enter' || e.key === ' ') { onActivate(); }
        };
        return button;
    }

    function injectNavbarButtons() {
        installMenuEntries();
        var appMenu = document.querySelector('[data-dojo-attach-point="applicationMenu"]');
        if (!appMenu || appMenu.style.visibility === 'hidden') { return; }

        if (!document.getElementById(CHAT_BUTTON_ID)) {
            appMenu.appendChild(createNavbarButton(CHAT_BUTTON_ID, 'Uxopian AI Chat', 'AI Chat', CHAT_ICON_PATH,
                function () { openChat(buildChatRequest()); }));
        }
        if (!document.getElementById(ADMIN_BUTTON_ID)) {
            appMenu.appendChild(createNavbarButton(ADMIN_BUTTON_ID, 'Uxopian AI Administration', 'AI Admin',
                ADMIN_ICON_PATH, openAdmin));
        }
    }

    function allButtonsInjected() {
        return document.getElementById(CHAT_BUTTON_ID) && document.getElementById(ADMIN_BUTTON_ID);
    }

    function injectUntilPresent() {
        var retries = 0;
        (function attempt() {
            injectNavbarButtons();
            if (!allButtonsInjected() && retries++ < MAX_INJECT_RETRIES) {
                setTimeout(attempt, INJECT_RETRY_DELAY_MS);
            }
        })();
    }

    // Dojo renders the application menu well after this script runs, so the buttons are
    // (re)injected on DOM changes too, not just via the retry loop.
    function observeApplicationMenu() {
        var observer = new MutationObserver(function () {
            if (allButtonsInjected()) {
                observer.disconnect();
                return;
            }
            injectNavbarButtons();
        });
        var options = { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] };
        if (document.body) {
            observer.observe(document.body, options);
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                observer.observe(document.body, options);
            });
        }
    }

    // The actions open next to the click that led to them: ICN gives an action handler the items, not the
    // pointer position.
    document.addEventListener('mousedown', function (e) {
        _lastPointer = { x: e.clientX, y: e.clientY };
    }, true);

    if (typeof MutationObserver !== 'undefined') {
        observeApplicationMenu();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectUntilPresent);
    } else {
        injectUntilPresent();
    }
})();
