(function () {
    var uxopianHost = '@uxopian.ai.host@';
    var wsHost = uxopianHost.replace('https://', 'wss://').replace('http://', 'ws://');
    var jsUrl   = uxopianHost + '/api/web-components/chat/script';
    var cssUrl  = uxopianHost + '/api/web-components/chat/style';
    var _assetsPromise = null;

    function fetchToken() {
        return new Promise(function (resolve, reject) {
            ecm.model.Request.invokePluginService('UxopianPlugin', 'UxopianProxyService', {
                requestParams: { op: 'token' },
                requestCompleteCallback: function (r) {
                    if (r && r.token) { resolve(r.token); }
                    else { reject(new Error('Token manquant : ' + JSON.stringify(r))); }
                },
                requestErrorCallback: function (e) {
                    reject(new Error('invokePluginService error: ' + JSON.stringify(e)));
                }
            });
        });
    }

    function fetchWithAuth(url, token) {
        return fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
    }

    function injectCss(token) {
        if (document.querySelector('style[data-uxopian-css]')) { return; }
        fetchWithAuth(cssUrl, token)
            .then(function (r) { return r.text(); })
            .then(function (css) {
                var style = document.createElement('style');
                style.setAttribute('data-uxopian-css', '1');
                style.textContent = css;
                document.head.appendChild(style);
            })
            .catch(function (err) { console.error('[Uxopian AI] Erreur chargement CSS:', err); });
    }

    function injectScript(token) {
        return fetchWithAuth(jsUrl, token)
            .then(function (r) {
                if (!r.ok) { throw new Error('Script fetch failed: ' + r.status); }
                return r.text();
            })
            .then(function (code) {
                return new Promise(function (resolve, reject) {
                    var blob = new Blob([code], { type: 'application/javascript' });
                    var blobUrl = URL.createObjectURL(blob);
                    var script = document.createElement('script');
                    script.onload = function () { URL.revokeObjectURL(blobUrl); resolve(); };
                    script.onerror = function () { URL.revokeObjectURL(blobUrl); reject(new Error('script eval failed')); };
                    script.src = blobUrl;
                    document.head.appendChild(script);
                });
            });
    }

    function loadAssets() {
        if (typeof window.createChat === 'function') { return Promise.resolve(); }
        if (_assetsPromise) { return _assetsPromise; }
        _assetsPromise = fetchToken()
            .then(function (token) {
                injectCss(token);
                return injectScript(token);
            })
            .catch(function (err) { _assetsPromise = null; return Promise.reject(err); });
        return _assetsPromise;
    }

    function openChat(request) {
        loadAssets()
            .then(function () {
                if (typeof window.createChat !== 'function') {
                    console.error('[Uxopian AI] window.createChat introuvable.');
                    return;
                }
                window.createChat({ endpoint: uxopianHost, wsEndpoint: wsHost, request: request });
            }).catch(function (err) {
                console.error('[Uxopian AI] Erreur chargement assets:', err);
            });
    }

    function buildChatRequest(docId, objectStore, docName) {
        return {
            inputs: [{
                role: 'system',
                content: [{
                    type: 'PROMPT',
                    value: '',
                    payload: {}
                }]
            }]
        };
    }

    window._uxopianAI = { openChat: openChat, buildChatRequest: buildChatRequest };

    function injectNavbarButton() {
        if (document.getElementById('uxopian-ai-navbar-btn')) { return; }

        var appMenu = document.querySelector(
            '[data-dojo-attach-point="applicationMenu"]'
        );
        if (!appMenu || appMenu.style.visibility === 'hidden') { return; }

        var btn = document.createElement('div');
        btn.id    = 'uxopian-ai-navbar-btn';
        btn.title = 'Chat IA Uxopian';
        btn.setAttribute('role', 'button');
        btn.setAttribute('tabindex', '0');
        btn.style.cssText = [
            'display:inline-flex',
            'align-items:center',
            'gap:5px',
            'padding:4px 10px',
            'cursor:pointer',
            'color:inherit',
            'font-size:13px',
            'user-select:none',
            'vertical-align:middle'
        ].join(';');

        btn.innerHTML =
            '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" ' +
            'viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0">' +
            '<path d="M12 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22' +
            'l4.832-1.438A9.953 9.953 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2z"/>' +
            '</svg>' +
            '<span>AI Chat</span>';

        btn.onclick = function () {
            openChat(buildChatRequest('', '', ''));
        };
        btn.onkeydown = function (e) {
            if (e.key === 'Enter' || e.key === ' ') { btn.onclick(); }
        };

        appMenu.appendChild(btn);
        console.log('[Uxopian AI] Bouton navbar injecté dans applicationMenu.');
    }

    // Polling + MutationObserver pour catcher le moment où ICN rend la navbar
    var _retries = 0;
    function tryInject() {
        injectNavbarButton();
        if (!document.getElementById('uxopian-ai-navbar-btn') && _retries++ < 60) {
            setTimeout(tryInject, 300);
        }
    }

    if (typeof MutationObserver !== 'undefined') {
        var obs = new MutationObserver(function () {
            if (document.getElementById('uxopian-ai-navbar-btn')) {
                obs.disconnect();
                return;
            }
            injectNavbarButton();
        });
        var startObs = function () {
            if (document.body) {
                obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] });
            }
        };
        if (document.body) { startObs(); }
        else { document.addEventListener('DOMContentLoaded', startObs); }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', tryInject);
    } else {
        tryInject();
    }
})();

// ─────────────────────────────────────────────────────────────────────────────
// Module AMD : handler de l'action contextuelle sur un document.
// ICN require ce module quand l'utilisateur déclenche l'action "Ouvrir dans Uxopian".
// ─────────────────────────────────────────────────────────────────────────────
define(['dojo/_base/declare'], function (declare) {
    return declare(null, {
        run: function (repository, items, callback) {
            var ai = window._uxopianAI;
            var docId       = (items && items[0]) ? (items[0].id   || '') : '';
            var docName     = (items && items[0]) ? (items[0].name || '') : '';
            var objectStore = (repository && repository.id) ? repository.id : '';
            ai.openChat(ai.buildChatRequest(docId, objectStore, docName));
            if (callback) { callback(); }
        }
    });
});
