(function () {
    var PLUGIN_ID = 'UxopianPlugin';
    var SERVICE_ID = 'UxopianProxyService';
    var CHAT_BUTTON_ID = 'uxopian-ai-navbar-btn';
    var ADMIN_BUTTON_ID = 'uxopian-ai-admin-btn';
    var MAX_INJECT_RETRIES = 60;
    var INJECT_RETRY_DELAY_MS = 300;

    var _assetsPromise = null;
    var _hostPromise = null;
    var _interceptorInstalled = false;

    function invokeProxyService(op) {
        return new Promise(function (resolve, reject) {
            ecm.model.Request.invokePluginService(PLUGIN_ID, SERVICE_ID, {
                requestParams: { op: op },
                requestCompleteCallback: resolve,
                requestErrorCallback: function (e) {
                    reject(new Error('invokePluginService error: ' + JSON.stringify(e)));
                }
            });
        });
    }

    function fetchUxopianHost() {
        if (!_hostPromise) {
            _hostPromise = invokeProxyService('config')
                .then(function (r) {
                    if (!r || !r.uxopianAiHost) {
                        throw new Error('Uxopian AI Host URL is not configured. Set it in the ICN Admin '
                            + 'Console (Plug-ins > Uxopian Plugin > Configure).');
                    }
                    return r.uxopianAiHost;
                })
                .catch(function (err) {
                    _hostPromise = null;
                    return Promise.reject(err);
                });
        }
        return _hostPromise;
    }

    function fetchToken(op) {
        return invokeProxyService(op).then(function (r) {
            if (!r || !r.token) {
                throw new Error('Missing token: ' + JSON.stringify(r));
            }
            return r.token;
        });
    }

    function getWsHost(host) {
        return host.replace('https://', 'wss://').replace('http://', 'ws://');
    }

    function injectCss(host) {
        if (document.querySelector('link[data-uxopian-css]')) { return; }
        var link = document.createElement('link');
        link.setAttribute('data-uxopian-css', '1');
        link.rel = 'stylesheet';
        link.href = host + '/api/web-components/chat/style';
        document.head.appendChild(link);
    }

    function injectScript(host) {
        return new Promise(function (resolve, reject) {
            if (document.querySelector('script[data-uxopian-js]')) { resolve(); return; }
            var script = document.createElement('script');
            script.setAttribute('data-uxopian-js', '1');
            script.onload = resolve;
            script.onerror = function () { reject(new Error('script load failed')); };
            script.src = host + '/api/web-components/chat/script';
            document.head.appendChild(script);
        });
    }

    function loadAssets(host) {
        if (typeof window.createChat === 'function') { return Promise.resolve(); }
        if (_assetsPromise) { return _assetsPromise; }
        injectCss(host);
        _assetsPromise = injectScript(host)
            .catch(function (err) { _assetsPromise = null; return Promise.reject(err); });
        return _assetsPromise;
    }

    // The token cannot be passed to createChat, so it is attached transparently. A fresh one per
    // request: a chat session routinely outlives the JWT's TTL.
    function installAuthInterceptor(host) {
        if (_interceptorInstalled) { return; }
        _interceptorInstalled = true;

        var NativeXHR = window.XMLHttpRequest;
        function PatchedXHR() {
            var xhr = new NativeXHR();
            var nativeOpen = xhr.open.bind(xhr);
            var nativeSend = xhr.send.bind(xhr);
            var targetsHost = false;
            xhr.open = function (method, url) {
                nativeOpen.apply(xhr, arguments);
                targetsHost = typeof url === 'string' && url.indexOf(host) === 0;
            };
            xhr.send = function (body) {
                if (!targetsHost) {
                    nativeSend(body);
                    return;
                }
                fetchToken('token').then(function (token) {
                    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
                    nativeSend(body);
                });
            };
            return xhr;
        }
        PatchedXHR.prototype = NativeXHR.prototype;
        window.XMLHttpRequest = PatchedXHR;

        var nativeFetch = window.fetch;
        window.fetch = function (input, init) {
            var url = typeof input === 'string' ? input : (input && input.url);
            if (!url || url.indexOf(host) !== 0) {
                return nativeFetch.call(this, input, init);
            }
            var self = this;
            return fetchToken('token').then(function (token) {
                var headers = Object.assign({}, init && init.headers, { 'Authorization': 'Bearer ' + token });
                return nativeFetch.call(self, input, Object.assign({}, init, { headers: headers }));
            });
        };
    }

    function openChat(request) {
        var host;
        fetchUxopianHost()
            .then(function (fetchedHost) {
                host = fetchedHost;
                return loadAssets(host);
            })
            .then(function () {
                installAuthInterceptor(host);
                if (typeof window.createChat !== 'function') {
                    console.error('[Uxopian AI] window.createChat not found.');
                    return;
                }
                window.createChat({ endpoint: host, wsEndpoint: getWsHost(host), request: request });
            })
            .catch(function (err) {
                console.error('[Uxopian AI] Failed to open chat:', err);
            });
    }

    function buildChatRequest() {
        return { inputs: [] };
    }

    function openAdmin() {
        fetchUxopianHost()
            .then(function (host) {
                // Anchored on the fixed /gui/gateway/ base: the number of segments after it varies
                // by route, so trimming a fixed number off the configured host would not work.
                var loginUrl = host.replace(/(\/gui\/gateway\/).*$/, '$1auth/login');
                var adminPath = (host + '/admin/').replace(/^https?:\/\/[^/]+/, '');
                return fetchToken('admin-token').then(function (token) {
                    var exchangeUrl = loginUrl
                        + '?providerId=FileNetProvider'
                        + '&token=' + encodeURIComponent(token)
                        + '&redirect=' + encodeURIComponent(adminPath);
                    (window.top || window).open(exchangeUrl, '_blank');
                });
            })
            .catch(function (err) {
                console.error('[Uxopian AI] Failed to open admin:', err);
            });
    }

    window._uxopianAI = { openChat: openChat, buildChatRequest: buildChatRequest, openAdmin: openAdmin };

    var BTN_STYLE = [
        'display:inline-flex',
        'align-items:center',
        'gap:5px',
        'padding:4px 10px',
        'cursor:pointer',
        'color:inherit',
        'font-size:13px',
        'user-select:none',
        'vertical-align:middle'
    ].join(';');

    var CHAT_ICON_PATH = 'M12 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22'
        + 'l4.832-1.438A9.953 9.953 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2z';

    var ADMIN_ICON_PATH = 'M12 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7zm7.43-2.97c.04-.32.07-.65.07-.98s-.03-.67-.07-1'
        + 'l2.11-1.63c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98'
        + 'l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98'
        + 'l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64L4.57 11c-.04.33-.07.65-.07.98'
        + 's.03.67.07 1l-2.11 1.63c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1'
        + 'c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42'
        + 'l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46'
        + 'c.12-.22.07-.49-.12-.64l-2.11-1.63z';

    function createNavbarButton(id, title, label, iconPath, onActivate) {
        var button = document.createElement('div');
        button.id = id;
        button.title = title;
        button.setAttribute('role', 'button');
        button.setAttribute('tabindex', '0');
        button.style.cssText = BTN_STYLE;
        button.innerHTML =
            '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" ' +
            'viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0">' +
            '<path d="' + iconPath + '"/>' +
            '</svg>' +
            '<span>' + label + '</span>';
        button.onclick = onActivate;
        button.onkeydown = function (e) {
            if (e.key === 'Enter' || e.key === ' ') { onActivate(); }
        };
        return button;
    }

    function injectNavbarButtons() {
        var appMenu = document.querySelector('[data-dojo-attach-point="applicationMenu"]');
        if (!appMenu || appMenu.style.visibility === 'hidden') { return; }

        if (!document.getElementById(CHAT_BUTTON_ID)) {
            appMenu.appendChild(createNavbarButton(CHAT_BUTTON_ID, 'Uxopian AI Chat', 'AI Chat', CHAT_ICON_PATH,
                function () { openChat(buildChatRequest()); }));
        }
        if (!document.getElementById(ADMIN_BUTTON_ID)) {
            appMenu.appendChild(createNavbarButton(ADMIN_BUTTON_ID, 'Uxopian AI Administration', 'AI Admin',
                ADMIN_ICON_PATH, openAdmin));
        }
    }

    function allButtonsInjected() {
        return document.getElementById(CHAT_BUTTON_ID) && document.getElementById(ADMIN_BUTTON_ID);
    }

    function injectUntilPresent() {
        var retries = 0;
        (function attempt() {
            injectNavbarButtons();
            if (!allButtonsInjected() && retries++ < MAX_INJECT_RETRIES) {
                setTimeout(attempt, INJECT_RETRY_DELAY_MS);
            }
        })();
    }

    // Dojo renders the application menu well after this script runs, so the buttons are
    // (re)injected on DOM changes too, not just via the retry loop.
    function observeApplicationMenu() {
        var observer = new MutationObserver(function () {
            if (allButtonsInjected()) {
                observer.disconnect();
                return;
            }
            injectNavbarButtons();
        });
        var options = { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] };
        if (document.body) {
            observer.observe(document.body, options);
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                observer.observe(document.body, options);
            });
        }
    }

    if (typeof MutationObserver !== 'undefined') {
        observeApplicationMenu();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectUntilPresent);
    } else {
        injectUntilPresent();
    }
})();
