(function () {
    var uxopianHost = '@uxopian.ai.host@';
    var wsHost = uxopianHost.replace('https://', 'wss://').replace('http://', 'ws://');
    var jsUrl = uxopianHost + '/api/web-components/chat/script';
    var cssUrl = uxopianHost + '/api/web-components/chat/style';
    var adminUrl = uxopianHost + '/admin/';
    var _assetsPromise = null;

    function fetchToken() {
        return new Promise(function (resolve, reject) {
            ecm.model.Request.invokePluginService('UxopianPlugin', 'UxopianProxyService', {
                requestParams: { op: 'token' },
                requestCompleteCallback: function (r) {
                    if (r && r.token) { resolve(r.token); }
                    else { reject(new Error('Token manquant : ' + JSON.stringify(r))); }
                },
                requestErrorCallback: function (e) {
                    reject(new Error('invokePluginService error: ' + JSON.stringify(e)));
                }
            });
        });
    }

    function fetchWithAuth(url, token) {
        return fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
    }

    function injectCss() {
        if (document.querySelector('link[data-uxopian-css]')) { return; }
        var link = document.createElement('link');
        link.setAttribute('data-uxopian-css', '1');
        link.rel = 'stylesheet';
        link.href = cssUrl;
        document.head.appendChild(link);
    }

    function injectScript() {
        return new Promise(function (resolve, reject) {
            if (document.querySelector('script[data-uxopian-js]')) { resolve(); return; }
            var script = document.createElement('script');
            script.setAttribute('data-uxopian-js', '1');
            script.onload = resolve;
            script.onerror = function () { reject(new Error('script load failed')); };
            script.src = jsUrl;
            document.head.appendChild(script);
        });
    }

    function loadAssets() {
        if (typeof window.createChat === 'function') { return Promise.resolve(); }
        if (_assetsPromise) { return _assetsPromise; }
        injectCss();
        _assetsPromise = injectScript()
            .catch(function (err) { _assetsPromise = null; return Promise.reject(err); });
        return _assetsPromise;
    }

    var _interceptorInstalled = false;

    function installAuthInterceptor(token) {
        if (_interceptorInstalled) { return; }
        _interceptorInstalled = true;

        var NativeXHR = window.XMLHttpRequest;
        function PatchedXHR() {
            var xhr = new NativeXHR();
            var _open = xhr.open.bind(xhr);
            xhr.open = function (method, url) {
                _open.apply(xhr, arguments);
                if (typeof url === 'string' && url.indexOf(uxopianHost) === 0) {
                    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
                }
            };
            return xhr;
        }
        PatchedXHR.prototype = NativeXHR.prototype;
        window.XMLHttpRequest = PatchedXHR;

        var nativeFetch = window.fetch;
        window.fetch = function (input, init) {
            var url = typeof input === 'string' ? input : (input && input.url);
            if (url && url.indexOf(uxopianHost) === 0) {
                init = init || {};
                init.headers = Object.assign({}, init.headers, { 'Authorization': 'Bearer ' + token });
            }
            return nativeFetch.call(this, input, init);
        };
    }

    function openChat(request) {
        loadAssets()
            .then(function () { return fetchToken(); })
            .then(function (token) {
                installAuthInterceptor(token);
                if (typeof window.createChat !== 'function') {
                    console.error('[Uxopian AI] window.createChat introuvable.');
                    return;
                }
                window.createChat({ endpoint: uxopianHost, wsEndpoint: wsHost, request: request });
            }).catch(function (err) {
                console.error('[Uxopian AI] Erreur chargement assets:', err);
            });
    }

    function buildChatRequest() {
        return {
            inputs: [{
                role: 'system',
                content: [{
                    type: 'PROMPT',
                    value: 'filenetAssistant',
                    payload: {}
                }]
            }]
        };
    }

    var loginUrl = uxopianHost.replace(/[^/]+$/, 'auth/login');
    var adminPath = adminUrl.replace(/^https?:\/\/[^/]+/, '');

    function fetchAdminToken() {
        return new Promise(function (resolve, reject) {
            ecm.model.Request.invokePluginService('UxopianPlugin', 'UxopianProxyService', {
                requestParams: { op: 'admin-token' },
                requestCompleteCallback: function (r) {
                    if (r && r.token) { resolve(r.token); }
                    else { reject(new Error('Token manquant : ' + JSON.stringify(r))); }
                },
                requestErrorCallback: function (e) {
                    reject(new Error('invokePluginService error: ' + JSON.stringify(e)));
                }
            });
        });
    }

    function openAdmin() {
        fetchAdminToken()
            .then(function (token) {
                var exchangeUrl = loginUrl
                    + '?providerId=FileNetProvider'
                    + '&token=' + encodeURIComponent(token)
                    + '&redirect=' + encodeURIComponent(adminPath);
                (window.top || window).open(exchangeUrl, '_blank');
            })
            .catch(function (err) {
                console.error('[Uxopian AI] Erreur ouverture admin:', err);
            });
    }

    window._uxopianAI = { openChat: openChat, buildChatRequest: buildChatRequest, openAdmin: openAdmin };

    var BTN_STYLE = [
        'display:inline-flex',
        'align-items:center',
        'gap:5px',
        'padding:4px 10px',
        'cursor:pointer',
        'color:inherit',
        'font-size:13px',
        'user-select:none',
        'vertical-align:middle'
    ].join(';');

    function injectNavbarButton() {
        var appMenu = document.querySelector('[data-dojo-attach-point="applicationMenu"]');
        if (!appMenu || appMenu.style.visibility === 'hidden') { return; }

        if (!document.getElementById('uxopian-ai-navbar-btn')) {
            var btn = document.createElement('div');
            btn.id = 'uxopian-ai-navbar-btn';
            btn.title = 'Chat IA Uxopian';
            btn.setAttribute('role', 'button');
            btn.setAttribute('tabindex', '0');
            btn.style.cssText = BTN_STYLE;
            btn.innerHTML =
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" ' +
                'viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0">' +
                '<path d="M12 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22' +
                'l4.832-1.438A9.953 9.953 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2z"/>' +
                '</svg>' +
                '<span>AI Chat</span>';
            btn.onclick = function () { openChat(buildChatRequest()); };
            btn.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { btn.onclick(); } };
            appMenu.appendChild(btn);
        }

        if (!document.getElementById('uxopian-ai-admin-btn')) {
            var adminBtn = document.createElement('div');
            adminBtn.id = 'uxopian-ai-admin-btn';
            adminBtn.title = 'Administration IA Uxopian';
            adminBtn.setAttribute('role', 'button');
            adminBtn.setAttribute('tabindex', '0');
            adminBtn.style.cssText = BTN_STYLE;
            adminBtn.innerHTML =
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" ' +
                'viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0">' +
                '<path d="M12 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7zm7.43-2.97c.04-.32.07-.65.07-.98s-.03-.67-.07-1' +
                'l2.11-1.63c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98' +
                'l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98' +
                'l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64L4.57 11c-.04.33-.07.65-.07.98' +
                's.03.67.07 1l-2.11 1.63c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1' +
                'c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42' +
                'l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46' +
                'c.12-.22.07-.49-.12-.64l-2.11-1.63z"/>' +
                '</svg>' +
                '<span>Admin IA</span>';
            adminBtn.onclick = function () { openAdmin(); };
            adminBtn.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { adminBtn.onclick(); } };
            appMenu.appendChild(adminBtn);
        }
    }

    function allButtonsInjected() {
        return document.getElementById('uxopian-ai-navbar-btn') && document.getElementById('uxopian-ai-admin-btn');
    }

    function tryInject() {
        var retries = 0;
        (function attempt() {
            injectNavbarButton();
            if (!allButtonsInjected() && retries++ < 60) {
                setTimeout(attempt, 300);
            }
        })();
    }

    if (typeof MutationObserver !== 'undefined') {
        var obs = new MutationObserver(function () {
            if (allButtonsInjected()) {
                obs.disconnect();
                return;
            }
            injectNavbarButton();
        });
        if (document.body) {
            obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] });
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] });
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', tryInject);
    } else {
        tryInject();
    }
})();

define(['dojo/_base/declare'], function (declare) {
    return declare(null, {
        run: function (repository, items, callback) {
            var ai = window._uxopianAI;
            ai.openChat(ai.buildChatRequest());
            if (callback) { callback(); }
        }
    });
});
