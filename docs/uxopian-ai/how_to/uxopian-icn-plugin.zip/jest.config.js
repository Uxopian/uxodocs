module.exports = {
    testEnvironment: 'jsdom',
    testMatch: ['**/src/test/javascript/**/*.test.js']
};
