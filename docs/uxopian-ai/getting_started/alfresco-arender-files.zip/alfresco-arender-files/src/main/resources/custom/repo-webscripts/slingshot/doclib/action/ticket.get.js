// Returns the authentication ticket used in this request.
// Share passes alf_ticket as a query parameter when calling repository webscripts.
model.ticket = args.alf_ticket || "";
