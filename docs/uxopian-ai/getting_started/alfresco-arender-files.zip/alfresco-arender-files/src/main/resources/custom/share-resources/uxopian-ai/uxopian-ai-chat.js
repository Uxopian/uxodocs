(function () {
    var uxopianHost = 'UXOPIAN_AI_HOST_PLACEHOLDER';
    var wsHost = uxopianHost.replace('https://', 'wss://').replace('http://', 'ws://');

    // Resolve assets base from the script's own URL so they are served from the same
    // Share origin — avoids cross-origin authentication/CSP issues with the gateway.
    var _scriptBase = (function () {
        var scripts = document.getElementsByTagName('script');
        for (var i = 0; i < scripts.length; i++) {
            if (scripts[i].src && scripts[i].src.indexOf('uxopian-ai-chat.js') !== -1) {
                return scripts[i].src.replace(/\/uxopian-ai-chat\.js.*$/, '');
            }
        }
        return uxopianHost;
    })();
    var jsUrl = _scriptBase + '/components/chat/uxopian-ai-chat-web-components.js';
    var cssUrl = _scriptBase + '/components/chat/uxopian-ai-web-components.css';

    var _assetsPromise = null;

    function loadAssets() {
        if (typeof window.createChat === 'function') {
            return Promise.resolve();
        }
        if (_assetsPromise) {
            return _assetsPromise;
        }
        if (!document.querySelector('link[href="' + cssUrl + '"]')) {
            var link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = cssUrl;
            document.head.appendChild(link);
        }
        _assetsPromise = new Promise(function (resolve, reject) {
            var script = document.createElement('script');
            script.src = jsUrl;
            script.async = true;
            script.onload = resolve;
            script.onerror = function (err) {
                _assetsPromise = null;
                reject(err);
            };
            document.head.appendChild(script);
        });
        return _assetsPromise;
    }

    loadAssets().catch(function (err) {
        console.error('[Uxopian AI] Failed to load chat assets:', err);
    });

    function openChat(request) {
        loadAssets().then(function () {
            if (typeof window.createChat !== 'function') {
                console.error('[Uxopian AI] window.createChat not found.');
                return;
            }
            window.createChat({ endpoint: uxopianHost, wsEndpoint: wsHost, request: request });
        }).catch(function (err) {
            console.error('[Uxopian AI] Failed to load chat assets:', err);
        });
    }

    function extractNodeInfo(fileOrRecord) {
        var nodeRef, docName;
        if (fileOrRecord) {
            if (fileOrRecord.node && fileOrRecord.node.nodeRef) {
                nodeRef = fileOrRecord.node.nodeRef;
                docName = fileOrRecord.displayName
                    || (fileOrRecord.node.properties && fileOrRecord.node.properties['cm:name'])
                    || '';
            } else if (fileOrRecord.nodeRef) {
                nodeRef = fileOrRecord.nodeRef;
                docName = fileOrRecord.displayName || fileOrRecord.fileName || '';
            }
        }
        return { nodeId: nodeRef ? nodeRef.split('/').pop() : '', docName: docName || '' };
    }

    function singleDocRequest(promptId, nodeId, docName, extraPayload) {
        var payload = { alfrescoNodeId: nodeId, documentId: '', documentName: docName };
        if (extraPayload) {
            Object.keys(extraPayload).forEach(function (k) { payload[k] = extraPayload[k]; });
        }
        return { inputs: [{ role: 'user', content: [{ type: 'PROMPT', value: promptId, payload: payload }] }] };
    }

    var handlers = {

        onUxopianAiChat: function (fileOrRecord) {
            var info = extractNodeInfo(fileOrRecord);
            openChat({
                inputs: [{
                    role: 'system', content: [{
                        type: 'PROMPT', value: 'alfrescoAssistant',
                        payload: { alfrescoNodeId: info.nodeId, documentId: '', documentName: info.docName }
                    }]
                }]
            });
        },

        onUxopianAiSummarizeText: function (fileOrRecord) {
            var info = extractNodeInfo(fileOrRecord);
            openChat(singleDocRequest('summarizeDocumentText', info.nodeId, info.docName));
        },

        onUxopianAiSummarizeMarkdown: function (fileOrRecord) {
            var info = extractNodeInfo(fileOrRecord);
            openChat(singleDocRequest('summarizeDocumentMarkdown', info.nodeId, info.docName));
        },

        onUxopianAiTranslateFr: function (fileOrRecord) {
            var info = extractNodeInfo(fileOrRecord);
            openChat(singleDocRequest('translateToFrench', info.nodeId, info.docName));
        },

        onUxopianAiTranslateEn: function (fileOrRecord) {
            var info = extractNodeInfo(fileOrRecord);
            openChat(singleDocRequest('translateToEnglish', info.nodeId, info.docName));
        },

        onUxopianAiComparison: function (fileOrRecord) {
            var info = extractNodeInfo(fileOrRecord);
            openChat({
                inputs: [
                    {
                        role: 'system', content: [{
                            type: 'PROMPT', value: 'alfrescoAssistant',
                            payload: { alfrescoNodeId: info.nodeId, documentId: '', documentName: info.docName }
                        }]
                    },
                    {
                        role: 'user', content: [{
                            type: 'TEXT',
                            value: 'I want to compare this document with another one. Please ask me which document to compare it with, then use your tools to find and read it, and perform the comparison.'
                        }]
                    }
                ]
            });
        },

        onUxopianAiDetailedComparison: function (fileOrRecord) {
            var info = extractNodeInfo(fileOrRecord);
            openChat({
                inputs: [
                    {
                        role: 'system', content: [{
                            type: 'PROMPT', value: 'alfrescoAssistant',
                            payload: { alfrescoNodeId: info.nodeId, documentId: '', documentName: info.docName }
                        }]
                    },
                    {
                        role: 'user', content: [{
                            type: 'TEXT',
                            value: 'I want a detailed, exhaustive, point-by-point comparison of this document with another one. Please ask me which document to compare it with, then use your tools to find and read it, and perform the comparison.'
                        }]
                    }
                ]
            });
        },

        onUxopianAiExtractInvoice: function (fileOrRecord) {
            var info = extractNodeInfo(fileOrRecord);
            openChat(singleDocRequest('extractInvoiceNumber', info.nodeId, info.docName));
        }
    };

    var _retries = 0;
    var _maxRetries = 60;
    var _found = {};

    function registerHandler() {
        if (typeof Alfresco !== 'undefined'
            && Alfresco.doclib
            && Alfresco.doclib.Actions
            && Alfresco.doclib.Actions.prototype) {
            Object.keys(handlers).forEach(function (name) {
                Alfresco.doclib.Actions.prototype[name] = handlers[name];
            });
        }

        var allFound = true;
        ['DocumentActions', 'DocListToolbar', 'DocumentList'].forEach(function (className) {
            if (!_found[className]
                && typeof Alfresco !== 'undefined'
                && Alfresco[className]
                && Alfresco[className].prototype) {
                Object.keys(handlers).forEach(function (name) {
                    Alfresco[className].prototype[name] = handlers[name];
                });
                _found[className] = true;
                console.log('[Uxopian AI] Registered on Alfresco.' + className + '.prototype');
            }
            if (!_found[className]) { allFound = false; }
        });

        if (!allFound) {
            _retries++;
            if (_retries < _maxRetries) {
                setTimeout(registerHandler, 300);
            } else {
                var missing = ['DocumentActions', 'DocListToolbar', 'DocumentList']
                    .filter(function (k) { return !_found[k]; });
                console.log('[Uxopian AI] Not found (expected if not on page): ' + missing.join(', '));
            }
        }
    }

    Object.keys(handlers).forEach(function (name) { window[name] = handlers[name]; });
    registerHandler();

    var _navRetries = 0;
    function injectNavbarButton() {
        if (document.getElementById('uxopian-ai-navbar-btn')) { return; }

        var menubar = document.querySelector('#HEADER_APP_MENU_BAR [role="menubar"]')
                   || document.querySelector('#HEADER_APP_MENU_BAR .dijitMenuBar')
                   || document.querySelector('#alf-hd .links')
                   || document.querySelector('#alf-hd ul');

        if (!menubar) {
            _navRetries++;
            if (_navRetries < 50) {
                setTimeout(injectNavbarButton, 400);
            } else {
                console.warn('[Uxopian AI] Navbar not found after 50 attempts.');
            }
            return;
        }

        var item = document.createElement('div');
        item.id = 'uxopian-ai-navbar-btn';
        item.className = 'dijitReset dijitInline dijitMenuItem dijitMenuItemLabel alfresco-menus-_AlfMenuItemMixin';
        item.setAttribute('role', 'menuitem');
        item.setAttribute('tabindex', '-1');
        item.title = 'Chat IA – Assistant Xopia';
        item.style.cssText = 'cursor:pointer;user-select:none;';

        var span = document.createElement('span');
        span.className = 'alf-menu-bar-label-node';
        span.style.cssText = 'display:inline-flex;align-items:center;gap:5px;';
        span.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22l4.832-1.438A9.953 9.953 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2zm0 18a7.952 7.952 0 0 1-4.038-1.1l-.29-.173-2.868.853.853-2.868-.173-.29A7.952 7.952 0 0 1 4 12c0-4.411 3.589-8 8-8s8 3.589 8 8-3.589 8-8 8z"/></svg>Chat IA';

        item.appendChild(span);
        item.onclick = function (e) {
            e.preventDefault();
            openChat({ inputs: [{ role: 'system', content: [{ type: 'PROMPT', value: 'alfrescoAssistant', payload: { alfrescoNodeId: '', documentId: '', documentName: '' } }] }] });
        };

        menubar.appendChild(item);
        console.log('[Uxopian AI] Navbar button injected into menubar:', menubar.id || menubar.className);
    }

    function startNavbarInjection() {
        injectNavbarButton();
        if (typeof MutationObserver !== 'undefined') {
            var obs = new MutationObserver(function () {
                if (document.getElementById('uxopian-ai-navbar-btn')) { obs.disconnect(); return; }
                if (document.querySelector('#HEADER_APP_MENU_BAR [role="menubar"]') || document.querySelector('#alf-hd')) {
                    obs.disconnect();
                    injectNavbarButton();
                }
            });
            if (document.body) { obs.observe(document.body, { childList: true, subtree: true }); }
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startNavbarInjection);
    } else {
        startNavbarInjection();
    }

    function injectUserMenuAdminLink() {
        if (document.getElementById('uxopian-ai-user-menu-admin')) { return; }

        var menuGroup = document.getElementById('HEADER_USER_MENU');
        if (!menuGroup) { return; }

        var adminUrl = uxopianHost + '/admin/';
        var item = document.createElement('div');
        item.id = 'uxopian-ai-user-menu-admin';
        item.className = 'dijitReset dijitMenuItem alfresco-menus-AlfMenuItem';
        item.setAttribute('role', 'menuitem');
        item.setAttribute('tabindex', '-1');
        item.style.cssText = 'cursor:pointer;';

        var span = document.createElement('span');
        span.style.cssText = 'display:inline-flex;align-items:center;gap:6px;font-weight:500;';
        span.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0;opacity:0.85;"><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>Uxopian AI Admin page';

        item.appendChild(span);
        item.addEventListener('click', function () {
            window.open(adminUrl, '_blank');
        });

        menuGroup.insertBefore(item, menuGroup.firstChild);
        console.log('[Uxopian AI] Admin link injected into user menu');
    }

    function startUserMenuInjection() {
        injectUserMenuAdminLink();
        if (typeof MutationObserver !== 'undefined') {
            var obs = new MutationObserver(function () {
                if (document.getElementById('uxopian-ai-user-menu-admin')) { obs.disconnect(); return; }
                injectUserMenuAdminLink();
            });
            if (document.body) { obs.observe(document.body, { childList: true, subtree: true }); }
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startUserMenuInjection);
    } else {
        startUserMenuInjection();
    }
})();
