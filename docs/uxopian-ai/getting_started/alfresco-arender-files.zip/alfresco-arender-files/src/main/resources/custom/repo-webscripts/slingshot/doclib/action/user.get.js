// Returns the currently authenticated user's name.
model.userName = person.properties.userName;
